# Panel Rumah — ESP32 Relay + Sensor Dashboard

Sistem kontrol rumah berbasis **ESP32 NodeMCU-32S** dengan 4 relay, sensor **DHT22**
(suhu & kelembaban), RTC **DS3231**, dijalankan dengan **FreeRTOS**, terhubung ke
**MQTT broker EMQX**, dan dikendalikan lewat **dashboard web modern (neumorphism)**
yang bisa di-hosting gratis di Vercel/Netlify.

```
project/
├── firmware/
│   └── esp32_relay_control/
│       ├── esp32_relay_control.ino   <- kode utama (JANGAN diedit kredensialnya di sini)
│       └── config.h                  <- SEMUA pengaturan WiFi/MQTT/pin ada di sini
└── web/
    ├── index.html
    ├── css/style.css
    ├── js/app.js
    ├── netlify.toml
    └── vercel.json
```

---

## 1. Wiring

| Modul          | Pin ESP32          |
|-----------------|---------------------|
| Relay IN1       | GPIO 16             |
| Relay IN2       | GPIO 17             |
| Relay IN3       | GPIO 18             |
| Relay IN4       | GPIO 19             |
| DHT22 DATA      | GPIO 4 (+ pull-up 10kΩ ke 3V3 bila perlu) |
| DS3231 SDA      | GPIO 21              |
| DS3231 SCL      | GPIO 22              |

Semua modul relay & DS3231 & DHT22 dicatu daya sesuai spesifikasi modul (3V3/5V),
GND digabung ke GND ESP32.

> Sebagian besar modul relay 4-channel bersifat **active LOW** (relay aktif saat
> pin diberi sinyal LOW). Ini sudah diatur lewat `RELAY_ACTIVE_LOW true` di
> `config.h`. Jika relay-mu justru menyala terbalik, ubah nilainya ke `false`.

---

## 2. Firmware ESP32 (Arduino IDE)

### 2.1 Install board ESP32
Arduino IDE → Preferences → Additional Board URLs, tambahkan:
`https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
Lalu Boards Manager → install **esp32 by Espressif Systems**.
Pilih board: **ESP32 Dev Module**.

### 2.2 Install library (Library Manager)
- `PubSubClient` (Nick O'Leary)
- `ArduinoJson` (Benoit Blanchon) — versi 6.x
- `DHT sensor library` (Adafruit) + `Adafruit Unified Sensor`
- `RTClib` (Adafruit)

### 2.3 Edit `config.h`
Buka `firmware/esp32_relay_control/config.h`, isi:
```cpp
#define WIFI_SSID     "NAMA_WIFI_ANDA"
#define WIFI_PASSWORD "PASSWORD_WIFI_ANDA"
#define MQTT_HOST     "broker.emqx.io"     // lihat bagian EMQX di bawah
#define MQTT_PORT     1883
#define TOPIC_PREFIX  "rumah/esp32-relay-01"
```
`TOPIC_PREFIX` di firmware **harus identik** dengan `Topic Prefix` yang diisi di
tab **Setting** dashboard web, karena keduanya berkomunikasi lewat topic ini.

### 2.4 Upload
Sambungkan ESP32, pilih port yang benar, klik Upload. Buka Serial Monitor
(115200 baud) untuk memastikan WiFi & MQTT berhasil connect.

---

## 3. MQTT Broker — EMQX

Ada dua opsi:

### Opsi A — EMQX Public Test Broker (paling cepat, tanpa daftar)
- Host MQTT (untuk ESP32): `broker.emqx.io`, port `1883` (tanpa TLS, tanpa login)
- Host WebSocket (untuk dashboard web): `broker.emqx.io`, port `8083`, path `/mqtt` (ws)
  atau port `8084` (wss)
- **Catatan:** broker publik ini terbuka untuk umum. Gunakan `TOPIC_PREFIX` yang unik
  (misalnya tambahkan kode acak) agar tidak bentrok dengan pengguna lain, dan jangan
  gunakan untuk data sensitif.

### Opsi B — EMQX Cloud Serverless (gratis, direkomendasikan untuk pemakaian nyata)
1. Daftar di https://www.emqx.com/en/cloud → buat deployment **Serverless** (free tier).
2. Di dashboard EMQX Cloud, catat:
   - **MQTT host** (untuk ESP32), port `8883` (TLS) → isi di `config.h`:
     `MQTT_HOST`, `MQTT_PORT 8883`, `MQTT_USE_TLS true`
   - **WebSocket host** (untuk dashboard web), biasanya port `8084` (wss), path `/mqtt`
3. Buat **Authentication** (username/password) di EMQX Cloud → isi di `config.h`
   (`MQTT_USERNAME`, `MQTT_PASSWORD`) dan di tab Setting dashboard.
4. Isi `Protokol = wss`, `Port = 8084` di dashboard.

---

## 4. Dashboard Web

### 4.1 Jalankan lokal (opsional, untuk uji coba)
Buka langsung `web/index.html` di browser, atau jalankan server statis:
```bash
cd web
python3 -m http.server 8080
```
Buka `http://localhost:8080`.

### 4.2 Deploy ke GitHub + Vercel/Netlify

**Push ke GitHub:**
```bash
cd project
git init
git add .
git commit -m "Panel Rumah - ESP32 relay & sensor dashboard"
git branch -M main
git remote add origin https://github.com/USERNAME/panel-rumah.git
git push -u origin main
```

**Deploy dengan Netlify:**
1. Buka https://app.netlify.com → **Add new site → Import an existing project**
2. Hubungkan ke repo GitHub di atas
3. **Base directory**: `web`  |  **Publish directory**: `web` (atau `.` jika base sudah `web`)
4. Deploy — selesai, dashboard langsung online dengan URL `https://xxxx.netlify.app`

**Deploy dengan Vercel:**
1. Buka https://vercel.com → **Add New → Project** → import repo GitHub
2. **Root Directory**: pilih folder `web`
3. Framework preset: **Other** (static site, tidak perlu build command)
4. Deploy

### 4.3 Atur koneksi di dashboard
Setelah dashboard online, buka tab **Setting**:
- Isi Host, Port, Protokol (ws/wss), Path, Username/Password (jika ada), dan
  **Topic Prefix** (harus sama dengan `TOPIC_PREFIX` di firmware)
- Klik **Simpan & Sambungkan**
- Status koneksi akan berubah hijau ("Terhubung ke broker") di pojok kanan atas

Pengaturan disimpan di `localStorage` browser, jadi tidak perlu diisi ulang setiap
kali membuka dashboard di perangkat yang sama.

---

## 5. Fitur

- **Kontrol** — suhu & kelembaban real-time (tampil sejajar horizontal dengan gauge
  neumorphism), 4 kontrol relay (grid 2×2) dengan toggle & timer per-relay, info
  matahari terbit/terbenam hari ini, serta grafik statistik sensor (Chart.js,
  riwayat 30/60/120 data terakhir).
- **Otomasi** — jadwal otomatis dengan dua mode: **jam tetap** atau **berdasarkan
  matahari** (mis. "nyala 30 menit sebelum matahari terbenam, mati saat matahari
  terbit"), berulang per hari; serta automation rules (nyalakan/matikan relay
  otomatis berdasarkan ambang suhu/kelembaban).
- **Alert & Notifikasi** — kirim WhatsApp otomatis dari ESP32 (via CallMeBot) dan/atau
  notifikasi browser saat: suhu/kelembaban ekstrem, relay menyala terlalu lama
  ("macet"), atau perangkat kembali online setelah terputus. Riwayat alert
  tersimpan di tab Setting.
- **Setting** — konfigurasi broker MQTT, lokasi (lat/lon) untuk jadwal matahari,
  sinkronisasi jam DS3231 dari browser, ubah nama & ikon tiap relay, **latar
  belakang gambar** (upload/URL, dengan overlay & blur agar tetap nyaman dibaca),
  dan pilihan tema **terang/gelap** dengan ikon yang otomatis menyesuaikan
  (Line Awesome by Icons8).
- Semua jadwal, automation rule, lokasi & pengaturan alert **disimpan permanen
  di ESP32** (NVS/Preferences), tetap ada walau ESP32 restart — bukan hanya
  tersimpan di browser.
- Navigasi tab (Kontrol/Otomasi/Setting) lewat **floating bottom nav bar** dengan
  indikator berjalan.

### 5.1 Jadwal Berdasarkan Matahari (Astronomical Schedule)

ESP32 menghitung sendiri jam terbit & terbenam matahari setiap hari (algoritma
Sunrise Equation, **tanpa perlu internet/API luar** — hanya butuh koordinat lokasi
& jam RTC yang akurat). Saat membuat jadwal, pilih mode **"Berdasarkan Matahari"**,
lalu tentukan:
- **Anchor**: Matahari Terbit atau Matahari Terbenam
- **Selisih menit**: boleh negatif (sebelum) atau positif (sesudah), misalnya
  `-30` = 30 menit sebelum, `+15` = 15 menit sesudah

Koordinat lokasi diatur di tab **Setting → Lokasi**, atau lewat default di
`config.h` (`DEFAULT_LATITUDE`, `DEFAULT_LONGITUDE`).

### 5.2 Alert WhatsApp & Notifikasi

**WhatsApp (dari ESP32 langsung, tanpa server tambahan):**
1. Simpan nomor CallMeBot (+34 644 59 71 67) ke kontak WhatsApp Anda
2. Kirim pesan: `I allow callmebot to send me messages` ke nomor tersebut
3. Anda akan menerima API key balasan — isi ke `WA_PHONE` & `WA_APIKEY` di `config.h`,
   set `WA_ENABLED true`, lalu upload ulang firmware
4. Aktifkan toggle "Kirim alert WhatsApp dari perangkat" di dashboard (tab Setting)

**Notifikasi Browser:** aktifkan toggle "Notifikasi Browser" di tab Setting —
browser akan meminta izin, lalu notifikasi muncul otomatis saat ada alert
selama browser/tab berjalan (baik di foreground maupun background tab).
*Catatan:* ini bukan push notification tingkat OS yang bekerja saat browser
sepenuhnya tertutup (itu butuh server push/VAPID terpisah) — untuk alert yang
perlu sampai walau browser tertutup, gunakan jalur WhatsApp di atas.

Ambang alert (suhu tinggi/rendah, kelembaban tinggi/rendah, relay macet) diatur
di tab **Setting → Notifikasi & Alert**, dengan jeda otomatis 30 menit antar
alert bertipe sama supaya tidak spam.

### 5.3 Latar Belakang Gambar

Di tab **Setting → Latar Belakang**, pilih:
- **URL Gambar** — tempel link gambar langsung
- **Upload** — pilih gambar dari perangkat (otomatis dikompres & disimpan di
  `localStorage` browser, tidak diunggah ke server manapun)

Atur **opacity overlay** & **blur** agar latar tetap nyaman dan tidak mengganggu
keterbacaan kartu neumorphism di atasnya.

---

## 6. Referensi Topic MQTT

Semua topic diawali `TOPIC_PREFIX` (contoh: `rumah/esp32-relay-01`).

**Dipublish oleh ESP32 (retained kecuali disebutkan lain):**
| Topic | Isi |
|---|---|
| `/status/sensor` | `{temperature, humidity, time, date, epoch}` |
| `/status/relay` | `{relay1..relay4: bool}` |
| `/status/timer` | `{relay1..relay4: {active, remaining}}` |
| `/status/schedule` | array jadwal (jam tetap / matahari) |
| `/status/automation` | array rule |
| `/status/sun` | `{sunrise, sunset}` (jam hari ini, format "HH:MM") |
| `/status/location` | `{lat, lon}` |
| `/status/alert_settings` | pengaturan ambang alert + status WA |
| `/status/alert` | **(tidak retained)** `{type, message, time, epoch}` — event alert |
| `/status/online` | `"online"` / `"offline"` (Last Will) |

**Disubscribe oleh ESP32 (perintah dari dashboard):**
| Topic | Payload |
|---|---|
| `/cmd/relay` | `{relay:1-4, state:bool}` |
| `/cmd/relay_timer` | `{relay:1-4, duration:detik, state:bool}` |
| `/cmd/schedule_set` | `{index, relay, mode:0/1, onHour, onMinute, offHour, offMinute, onAnchor:0/1, onOffsetMin, offAnchor:0/1, offOffsetMin, days:[7], enabled}` |
| `/cmd/schedule_delete` | `{index}` |
| `/cmd/automation_set` | `{index, sensor:"T"/"H", operator:">"/"<", value, relay, state, enabled}` |
| `/cmd/automation_delete` | `{index}` |
| `/cmd/rtc_set` | `{epoch}` |
| `/cmd/location_set` | `{lat, lon}` |
| `/cmd/alert_set` | `{waEnabled, tempHighEn, tempHighVal, tempLowEn, tempLowVal, humHighEn, humHighVal, humLowEn, humLowVal, relayStuckEn, relayStuckMinutes}` |
| `/cmd/request_status` | `{}` |

`mode:0` = jadwal jam tetap (pakai `onHour/onMinute/offHour/offMinute`).
`mode:1` = jadwal matahari (pakai `onAnchor/onOffsetMin/offAnchor/offOffsetMin`,
anchor `0`=terbit, `1`=terbenam).

---

## 7. Troubleshooting

- **Dashboard tidak pernah "Terhubung"** → pastikan broker mendukung MQTT-over-WebSocket
  dan port/path sudah benar (browser TIDAK BISA connect ke port MQTT biasa 1883/8883,
  wajib lewat WebSocket 8083/ws atau 8084/wss).
- **ESP32 connect WiFi tapi MQTT gagal** → cek `MQTT_HOST`/`MQTT_PORT` di `config.h`,
  serta `MQTT_USE_TLS` harus `true` jika brokermu pakai TLS (port 8883).
- **Data sensor tidak muncul** → cek wiring DHT22 & pastikan `Serial Monitor` tidak
  menampilkan `[DHT22] Gagal membaca sensor!` terus-menerus.
- **Jadwal/relay timer tidak jalan tepat waktu** → pastikan jam DS3231 sudah benar,
  gunakan tombol "Set Waktu RTC dari Browser" di tab Setting. (Sejak v2.0.1, tombol
  ini otomatis mengonversi waktu browser ke zona waktu lokal sesuai
  `TIMEZONE_OFFSET_HOURS` di `config.h` sebelum disimpan ke RTC — pastikan nilai
  tersebut sudah sesuai zona waktu Anda, mis. `7` untuk WIB.)
- **Jam matahari terbit/terbenam salah** → cek koordinat lokasi di tab Setting →
  Lokasi, dan pastikan `TIMEZONE_OFFSET_HOURS` di `config.h` sesuai zona waktu Anda.
- **WhatsApp tidak terkirim** → pastikan `WA_ENABLED true` di `config.h` (perlu
  upload ulang firmware), nomor & API key CallMeBot benar, ESP32 punya akses
  internet keluar (bukan hanya ke broker MQTT lokal), dan toggle di dashboard
  sudah aktif.
- **Notifikasi browser tidak muncul** → periksa apakah izin notifikasi diblokir di
  pengaturan browser/situs, dan pastikan tab dashboard masih terbuka (notifikasi
  browser tidak bekerja saat browser tertutup total).
- **Gambar latar tidak tersimpan / gagal diterapkan** → ukuran gambar hasil upload
  mungkin melebihi kuota `localStorage` (~5-10MB tergantung browser); gunakan opsi
  URL Gambar sebagai gantinya, atau pilih gambar dengan resolusi lebih kecil.
- **ESP32 bootloop (restart terus-menerus) setelah menambah/mengubah jadwal** →
  sudah diperbaiki di v2.0.2: penyebabnya buffer JSON besar yang dulunya dialokasikan
  di stack task FreeRTOS (~8KB pada task ber-stack 10KB), sekarang dipindah ke heap.
  Jika Anda meng-upgrade dari firmware versi lebih lama dan sebelumnya sempat
  menyimpan jadwal, firmware baru otomatis mendeteksi data lama tidak cocok dan
  mengosongkannya (bukan memaksa membaca data yang bisa merusak indeks relay) —
  jadi jadwal & rule yang lama perlu dibuat ulang lewat dashboard setelah update ini.
- **Jam/suhu/kelembaban tidak ter-update otomatis, harus reload manual** → sudah
  diperbaiki di v2.1: sebelumnya, jika CDN Chart.js lambat/gagal dimuat (umum di
  jaringan seluler), inisialisasi dashboard berhenti total sebelum sempat
  menyambungkan MQTT. Sekarang tiap langkah inisialisasi berjalan independen —
  koneksi MQTT & tampilan sensor tetap berjalan normal walau grafik gagal dimuat.
