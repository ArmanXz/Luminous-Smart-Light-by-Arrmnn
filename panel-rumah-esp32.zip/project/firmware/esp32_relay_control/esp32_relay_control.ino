/*
 * =========================================================================
 *  ESP32 NodeMCU-32S — Kontrol 4 Relay + DS3231 + DHT22 via MQTT (EMQX)
 *  FreeRTOS + Jadwal Matahari (Astronomical) + Alert WhatsApp/Notifikasi
 * =========================================================================
 *
 *  LIBRARY YANG DIPERLUKAN (install lewat Arduino Library Manager):
 *   1. PubSubClient        - by Nick O'Leary
 *   2. ArduinoJson (v6.x)  - by Benoit Blanchon
 *   3. DHT sensor library  - by Adafruit
 *   4. Adafruit Unified Sensor - by Adafruit (dependensi DHT)
 *   5. RTClib              - by Adafruit
 *  (HTTPClient & WiFiClientSecure sudah bawaan core ESP32, tak perlu install)
 *
 *  BOARD: "ESP32 Dev Module" (NodeMCU-32S) — esp32 by Espressif Systems
 *
 *  WIRING:
 *   Relay IN1..IN4  -> GPIO 16, 17, 18, 19
 *   DHT22 DATA      -> GPIO 4 (+ resistor pull-up 10k ke 3V3 jika modul tanpa pull-up)
 *   DS3231 SDA/SCL  -> GPIO 21 / GPIO 22 (default I2C ESP32)
 *   Semua modul relay & DS3231 & DHT22 -> VCC 3V3/5V sesuai modul, GND gabung
 *
 *  Edit semua kredensial & pengaturan di file config.h
 * =========================================================================
 */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <Wire.h>
#include <RTClib.h>
#include <Preferences.h>
#include <math.h>
#include "config.h"

// ------------------------------------------------------------------------
//  OBJEK GLOBAL
// ------------------------------------------------------------------------
WiFiClient        wifiClientPlain;
WiFiClientSecure   wifiClientSecure;
PubSubClient       mqttClient(MQTT_USE_TLS ? (Client&)wifiClientSecure : (Client&)wifiClientPlain);

DHT     dht(DHT_PIN, DHT_TYPE);
RTC_DS3231 rtc;
Preferences prefs;

SemaphoreHandle_t dataMutex;     // melindungi semua variabel bersama di bawah ini

const uint8_t RELAY_PINS[4] = { RELAY1_PIN, RELAY2_PIN, RELAY3_PIN, RELAY4_PIN };

// Indeks tipe alert (untuk cooldown per-tipe)
#define ALERT_TEMP_HIGH        0
#define ALERT_TEMP_LOW         1
#define ALERT_HUM_HIGH         2
#define ALERT_HUM_LOW          3
#define ALERT_RELAY_STUCK_BASE 4   // pakai indeks 4..7 (per relay)
#define ALERT_DEVICE_ONLINE    8
#define ALERT_COUNT            9

// ------------------------------------------------------------------------
//  STRUKTUR DATA
// ------------------------------------------------------------------------
struct SensorData {
  float temperature = NAN;
  float humidity    = NAN;
  bool  valid        = false;
};

struct RelayTimer {
  bool     active   = false;
  uint32_t endEpoch = 0;   // waktu (unixtime) relay akan dibalik statusnya
  bool     revertTo = false;
};

struct ScheduleItem {
  bool    used     = false;
  uint8_t relay    = 0;
  uint8_t mode     = 0;      // 0 = jam tetap, 1 = berdasarkan matahari (astronomical)
  // --- mode 0: jam tetap ---
  uint8_t onHour   = 0, onMinute = 0;
  uint8_t offHour  = 0, offMinute = 0;
  // --- mode 1: berdasarkan matahari ---
  uint8_t onAnchor  = 1;   // 0 = matahari terbit, 1 = matahari terbenam
  int16_t onOffsetMin  = 0;   // selisih menit dari anchor (boleh negatif = "sebelum")
  uint8_t offAnchor = 0;
  int16_t offOffsetMin = 0;
  // --- umum ---
  bool    days[7]  = {true,true,true,true,true,true,true}; // 0=Minggu ... 6=Sabtu
  bool    enabled  = true;
  int16_t lastFiredMinuteOn  = -1;  // anti-trigger ganda di menit yang sama
  int16_t lastFiredMinuteOff = -1;
};

struct AutomationRule {
  bool    used     = false;
  char    sensorType = 'T';   // 'T' = suhu, 'H' = kelembaban
  char    op         = '>';   // '>' atau '<'
  float   value       = 30.0;
  uint8_t relay       = 0;
  bool    targetState = true;
  bool    enabled     = true;
  bool    lastTriggered = false; // status kondisi terakhir, untuk deteksi perubahan
};

struct AlertSettings {
  bool     waEnabled          = false;
  bool     tempHighEn         = false;
  float    tempHighVal        = 35.0;
  bool     tempLowEn          = false;
  float    tempLowVal         = 10.0;
  bool     humHighEn          = false;
  float    humHighVal         = 80.0;
  bool     humLowEn           = false;
  float    humLowVal          = 20.0;
  bool     relayStuckEn       = false;
  uint16_t relayStuckMinutes  = 180;
};

// ------------------------------------------------------------------------
//  VARIABEL BERSAMA (diakses oleh >1 task -> WAJIB pakai mutex)
// ------------------------------------------------------------------------
SensorData      g_sensor;
bool            g_relayState[4]        = {false,false,false,false};
uint32_t        g_relayOnSinceEpoch[4] = {0,0,0,0};   // 0 = sedang mati
RelayTimer      g_relayTimer[4];
ScheduleItem    g_schedules[MAX_SCHEDULES];
AutomationRule  g_rules[MAX_AUTOMATION_RULES];
AlertSettings   g_alert;
bool            g_needPublishSchedule   = true;
bool            g_needPublishAutomation = true;

// Lokasi & data matahari (tidak butuh mutex ketat karena hanya ditulis oleh TaskScheduler
// dan dibaca oleh task yang sama / publish yang dipanggil dari task yang sama)
double  g_latitude   = DEFAULT_LATITUDE;
double  g_longitude  = DEFAULT_LONGITUDE;
int     g_sunCalcDay   = -1;
int     g_sunCalcMonth = -1;
int     g_sunriseMinute = 6 * 60;
int     g_sunsetMinute  = 18 * 60;

uint32_t g_lastAlertEpoch[ALERT_COUNT] = {0};

// ------------------------------------------------------------------------
//  TOPIC HELPER
// ------------------------------------------------------------------------
String topicCmdRelay()           { return String(TOPIC_PREFIX) + "/cmd/relay"; }
String topicCmdRelayTimer()      { return String(TOPIC_PREFIX) + "/cmd/relay_timer"; }
String topicCmdScheduleSet()     { return String(TOPIC_PREFIX) + "/cmd/schedule_set"; }
String topicCmdScheduleDelete()  { return String(TOPIC_PREFIX) + "/cmd/schedule_delete"; }
String topicCmdAutomationSet()   { return String(TOPIC_PREFIX) + "/cmd/automation_set"; }
String topicCmdAutomationDelete(){ return String(TOPIC_PREFIX) + "/cmd/automation_delete"; }
String topicCmdRtcSet()          { return String(TOPIC_PREFIX) + "/cmd/rtc_set"; }
String topicCmdLocationSet()     { return String(TOPIC_PREFIX) + "/cmd/location_set"; }
String topicCmdAlertSet()        { return String(TOPIC_PREFIX) + "/cmd/alert_set"; }
String topicCmdRequestStatus()   { return String(TOPIC_PREFIX) + "/cmd/request_status"; }

String topicStatusSensor()       { return String(TOPIC_PREFIX) + "/status/sensor"; }
String topicStatusRelay()        { return String(TOPIC_PREFIX) + "/status/relay"; }
String topicStatusSchedule()     { return String(TOPIC_PREFIX) + "/status/schedule"; }
String topicStatusAutomation()   { return String(TOPIC_PREFIX) + "/status/automation"; }
String topicStatusTimer()        { return String(TOPIC_PREFIX) + "/status/timer"; }
String topicStatusOnline()       { return String(TOPIC_PREFIX) + "/status/online"; }
String topicStatusSun()          { return String(TOPIC_PREFIX) + "/status/sun"; }
String topicStatusLocation()     { return String(TOPIC_PREFIX) + "/status/location"; }
String topicStatusAlert()        { return String(TOPIC_PREFIX) + "/status/alert"; }
String topicStatusAlertSettings(){ return String(TOPIC_PREFIX) + "/status/alert_settings"; }

// ------------------------------------------------------------------------
//  RELAY HELPER
// ------------------------------------------------------------------------
void applyRelayPin(uint8_t idx, bool on) {
  bool level = RELAY_ACTIVE_LOW ? !on : on;
  digitalWrite(RELAY_PINS[idx], level ? HIGH : LOW);
}

// Dipanggil saat mutex SUDAH dipegang oleh caller. Mengurus state, pin fisik,
// dan pencatatan "sejak kapan relay ini menyala" (dipakai fitur alert relay macet).
void setRelayNoLock(uint8_t idx, bool on, const DateTime &now) {
  bool wasOn = g_relayState[idx];
  g_relayState[idx] = on;
  applyRelayPin(idx, on);
  if (on && !wasOn)  g_relayOnSinceEpoch[idx] = now.unixtime();
  if (!on)           g_relayOnSinceEpoch[idx] = 0;
}

// Dipanggil dari luar (mis. dari MQTT callback) — mengunci mutex sendiri.
void setRelay(uint8_t idx, bool on) {
  if (idx > 3) return;
  DateTime now = rtc.now();
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  setRelayNoLock(idx, on, now);
  xSemaphoreGive(dataMutex);
}

// ------------------------------------------------------------------------
//  PERHITUNGAN MATAHARI TERBIT / TERBENAM (Sunrise Equation, tanpa internet)
//  Referensi: algoritma almanak yang umum dipakai (mis. edwilliams.org/sunrise_sunset_algorithm.htm)
// ------------------------------------------------------------------------

// Mengembalikan jam lokal (desimal, 0-24) untuk matahari terbit/terbenam,
// atau -1 jika matahari tidak terbit/terbenam pada tanggal & lintang tsb
// (kasus ekstrem dekat kutub).
double sunEventLocalHour(int year, int month, int day, double lat, double lon, bool sunrise) {
  const double zenith = 90.8333; // sudut standar sunrise/sunset (sudah termasuk refraksi atmosfer)

  double N1 = floor(275.0 * month / 9.0);
  double N2 = floor((month + 9.0) / 12.0);
  double N3 = (1.0 + floor((year - 4.0 * floor(year / 4.0) + 2.0) / 3.0));
  double N  = N1 - (N2 * N3) + day - 30;

  double lngHour = lon / 15.0;
  double t = sunrise ? (N + ((6.0 - lngHour) / 24.0)) : (N + ((18.0 - lngHour) / 24.0));

  double M = (0.9856 * t) - 3.289;
  double L = M + (1.916 * sin(radians(M))) + (0.020 * sin(2 * radians(M))) + 282.634;
  L = fmod(L + 360.0, 360.0);

  double RA = degrees(atan(0.91764 * tan(radians(L))));
  RA = fmod(RA + 360.0, 360.0);
  double Lquadrant  = floor(L / 90.0) * 90.0;
  double RAquadrant = floor(RA / 90.0) * 90.0;
  RA = RA + (Lquadrant - RAquadrant);
  RA = RA / 15.0;

  double sinDec = 0.39782 * sin(radians(L));
  double cosDec = cos(asin(sinDec));

  double cosH = (cos(radians(zenith)) - (sinDec * sin(radians(lat)))) / (cosDec * cos(radians(lat)));
  if (cosH > 1.0 || cosH < -1.0) return -1.0;

  double H = sunrise ? (360.0 - degrees(acos(cosH))) : degrees(acos(cosH));
  H = H / 15.0;

  double T  = H + RA - (0.06571 * t) - 6.622;
  double UT = fmod(T - lngHour + 24.0, 24.0);
  double localT = fmod(UT + TIMEZONE_OFFSET_HOURS + 24.0, 24.0);
  return localT;
}

// Hitung ulang jam terbit/terbenam hari ini (hanya sekali per hari, di-cache)
void updateSunTimesIfNeeded(const DateTime &now) {
  if (g_sunCalcDay == now.day() && g_sunCalcMonth == now.month()) return;

  double sunriseH = sunEventLocalHour(now.year(), now.month(), now.day(), g_latitude, g_longitude, true);
  double sunsetH  = sunEventLocalHour(now.year(), now.month(), now.day(), g_latitude, g_longitude, false);
  if (sunriseH >= 0) g_sunriseMinute = (int)round(sunriseH * 60.0);
  if (sunsetH  >= 0) g_sunsetMinute  = (int)round(sunsetH * 60.0);

  g_sunCalcDay   = now.day();
  g_sunCalcMonth = now.month();

  if (mqttClient.connected()) publishSunStatus();
}

int scheduleAnchorMinute(uint8_t anchor) { return anchor == 0 ? g_sunriseMinute : g_sunsetMinute; }

String minutesToHHMM(int m) {
  m = ((m % 1440) + 1440) % 1440;
  char b[6];
  sprintf(b, "%02d:%02d", m / 60, m % 60);
  return String(b);
}

// ------------------------------------------------------------------------
//  NVS (PENYIMPANAN PERMANEN) — jadwal, rule, lokasi & alert tetap tersimpan
//  walau ESP32 mati/restart.
//
//  PENTING: setiap struct yang disimpan mentah (putBytes/getBytes) diberi
//  nomor versi. Kalau firmware di-upgrade dan layout struct berubah (field
//  ditambah/dipindah), membaca blob lama APA ADANYA akan membuat field
//  seperti "relay" berisi byte sampah/di luar jangkauan 0-3, yang bisa
//  membuat scheduler menulis di luar batas array -> crash -> bootloop.
//  Dengan nomor versi ini, data lama yang tidak cocok otomatis diabaikan
//  (dipakai nilai default) alih-alih dipaksa dibaca.
// ------------------------------------------------------------------------
#define SCHEDULE_STRUCT_VERSION 2
#define RULE_STRUCT_VERSION     1
#define ALERT_STRUCT_VERSION    1

void saveSchedulesToNVS() {
  prefs.begin("schedules", false);
  prefs.putUChar("ver", SCHEDULE_STRUCT_VERSION);
  prefs.putBytes("data", g_schedules, sizeof(g_schedules));
  prefs.end();
}
void loadSchedulesFromNVS() {
  prefs.begin("schedules", true);
  uint8_t ver = prefs.getUChar("ver", 0);
  bool ok = false;
  if (ver == SCHEDULE_STRUCT_VERSION && prefs.isKey("data")) {
    size_t got = prefs.getBytes("data", g_schedules, sizeof(g_schedules));
    ok = (got == sizeof(g_schedules));
  }
  prefs.end();
  if (!ok) {
    for (uint8_t i = 0; i < MAX_SCHEDULES; i++) g_schedules[i] = ScheduleItem();
    Serial.println("[NVS] Data jadwal versi lama/tidak cocok -> pakai default kosong.");
  }
}
void saveRulesToNVS() {
  prefs.begin("rules", false);
  prefs.putUChar("ver", RULE_STRUCT_VERSION);
  prefs.putBytes("data", g_rules, sizeof(g_rules));
  prefs.end();
}
void loadRulesFromNVS() {
  prefs.begin("rules", true);
  uint8_t ver = prefs.getUChar("ver", 0);
  bool ok = false;
  if (ver == RULE_STRUCT_VERSION && prefs.isKey("data")) {
    size_t got = prefs.getBytes("data", g_rules, sizeof(g_rules));
    ok = (got == sizeof(g_rules));
  }
  prefs.end();
  if (!ok) {
    for (uint8_t i = 0; i < MAX_AUTOMATION_RULES; i++) g_rules[i] = AutomationRule();
    Serial.println("[NVS] Data automation rule versi lama/tidak cocok -> pakai default kosong.");
  }
}
void saveLocationToNVS() {
  prefs.begin("loc", false);
  prefs.putDouble("lat", g_latitude);
  prefs.putDouble("lon", g_longitude);
  prefs.end();
}
void loadLocationFromNVS() {
  prefs.begin("loc", true);
  if (prefs.isKey("lat")) g_latitude  = prefs.getDouble("lat", g_latitude);
  if (prefs.isKey("lon")) g_longitude = prefs.getDouble("lon", g_longitude);
  prefs.end();
}
void saveAlertToNVS() {
  prefs.begin("alert", false);
  prefs.putUChar("ver", ALERT_STRUCT_VERSION);
  prefs.putBytes("data", &g_alert, sizeof(g_alert));
  prefs.end();
}
void loadAlertFromNVS() {
  prefs.begin("alert", true);
  uint8_t ver = prefs.getUChar("ver", 0);
  bool ok = false;
  if (ver == ALERT_STRUCT_VERSION && prefs.isKey("data")) {
    size_t got = prefs.getBytes("data", &g_alert, sizeof(g_alert));
    ok = (got == sizeof(g_alert));
  }
  prefs.end();
  if (!ok) {
    g_alert = AlertSettings();
    Serial.println("[NVS] Data alert versi lama/tidak cocok -> pakai default.");
  }
}

// ------------------------------------------------------------------------
//  WHATSAPP (CallMeBot) — dipanggil dari triggerAlert()
// ------------------------------------------------------------------------
String urlEncodeSimple(const String &s) {
  String out;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s.charAt(i);
    if (isalnum((unsigned char)c)) out += c;
    else if (c == ' ') out += "%20";
    else {
      char buf[4];
      sprintf(buf, "%%%02X", (unsigned char)c);
      out += buf;
    }
  }
  return out;
}

void sendWhatsAppAlert(const String &message) {
  if (!WA_ENABLED) return;
  if (!g_alert.waEnabled) return;
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClientSecure waClient;
  waClient.setInsecure(); // demi kesederhanaan; tidak memverifikasi sertifikat CallMeBot
  HTTPClient https;
  String url = "https://api.callmebot.com/whatsapp.php?phone=" + String(WA_PHONE) +
               "&text=" + urlEncodeSimple(message) + "&apikey=" + String(WA_APIKEY);
  if (https.begin(waClient, url)) {
    int code = https.GET();
    Serial.print("[WhatsApp] HTTP status: ");
    Serial.println(code);
    https.end();
  } else {
    Serial.println("[WhatsApp] Gagal memulai koneksi HTTPS");
  }
}

// ------------------------------------------------------------------------
//  ALERT — publish MQTT + (opsional) kirim WhatsApp, dengan cooldown per tipe
// ------------------------------------------------------------------------
void triggerAlert(uint8_t idx, const String &type, const String &message) {
  DateTime now = rtc.now();
  if (g_lastAlertEpoch[idx] != 0 && (now.unixtime() - g_lastAlertEpoch[idx]) < ALERT_COOLDOWN_SEC) return;
  g_lastAlertEpoch[idx] = now.unixtime();

  DynamicJsonDocument doc(320);
  doc["type"] = type;
  doc["message"] = message;
  char timeBuf[9];
  sprintf(timeBuf, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  doc["time"]  = timeBuf;
  doc["epoch"] = now.unixtime();
  String out; out.reserve(350);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusAlert().c_str(), (const uint8_t*)out.c_str(), out.length(), false);

  Serial.print("[ALERT] "); Serial.println(message);
  sendWhatsAppAlert(message);
}

// ------------------------------------------------------------------------
//  PUBLISH HELPERS
// ------------------------------------------------------------------------
void publishSensorData() {
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  SensorData s = g_sensor;
  xSemaphoreGive(dataMutex);
  if (!s.valid) return;

  DateTime now = rtc.now();
  DynamicJsonDocument doc(256);
  doc["temperature"] = round(s.temperature * 10) / 10.0;
  doc["humidity"]    = round(s.humidity * 10) / 10.0;
  char timeBuf[9], dateBuf[11];
  sprintf(timeBuf, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  sprintf(dateBuf, "%02d/%02d/%04d", now.day(), now.month(), now.year());
  doc["time"]  = timeBuf;
  doc["date"]  = dateBuf;
  doc["epoch"] = now.unixtime();

  String out; out.reserve(256);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusSensor().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishRelayStatus() {
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  bool r[4]; memcpy(r, g_relayState, sizeof(r));
  xSemaphoreGive(dataMutex);

  DynamicJsonDocument doc(128);
  doc["relay1"] = r[0];
  doc["relay2"] = r[1];
  doc["relay3"] = r[2];
  doc["relay4"] = r[3];
  String out; out.reserve(128);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusRelay().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishTimerStatus() {
  DateTime now = rtc.now();
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  RelayTimer t[4]; memcpy(t, g_relayTimer, sizeof(t));
  xSemaphoreGive(dataMutex);

  DynamicJsonDocument doc(256);
  for (uint8_t i = 0; i < 4; i++) {
    JsonObject o = doc.createNestedObject(String("relay") + (i + 1));
    o["active"] = t[i].active;
    o["remaining"] = t[i].active ? max(0, (int)(t[i].endEpoch - now.unixtime())) : 0;
  }
  String out; out.reserve(300);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusTimer().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishScheduleStatus() {
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  DynamicJsonDocument doc(3072);
  JsonArray arr = doc.to<JsonArray>();
  for (uint8_t i = 0; i < MAX_SCHEDULES; i++) {
    if (!g_schedules[i].used) continue;
    ScheduleItem &s = g_schedules[i];
    JsonObject o = arr.createNestedObject();
    o["index"]        = i;
    o["relay"]        = s.relay;
    o["mode"]         = s.mode;
    o["onHour"]       = s.onHour;
    o["onMinute"]     = s.onMinute;
    o["offHour"]      = s.offHour;
    o["offMinute"]    = s.offMinute;
    o["onAnchor"]     = s.onAnchor;
    o["onOffsetMin"]  = s.onOffsetMin;
    o["offAnchor"]    = s.offAnchor;
    o["offOffsetMin"] = s.offOffsetMin;
    JsonArray days = o.createNestedArray("days");
    for (uint8_t d = 0; d < 7; d++) days.add(s.days[d]);
    o["enabled"] = s.enabled;
  }
  xSemaphoreGive(dataMutex);
  String out; out.reserve(3072);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusSchedule().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishAutomationStatus() {
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  DynamicJsonDocument doc(1536);
  JsonArray arr = doc.to<JsonArray>();
  for (uint8_t i = 0; i < MAX_AUTOMATION_RULES; i++) {
    if (!g_rules[i].used) continue;
    JsonObject o = arr.createNestedObject();
    o["index"]    = i;
    o["sensor"]   = String(g_rules[i].sensorType);
    o["operator"] = String(g_rules[i].op);
    o["value"]    = g_rules[i].value;
    o["relay"]    = g_rules[i].relay;
    o["state"]    = g_rules[i].targetState;
    o["enabled"]  = g_rules[i].enabled;
  }
  xSemaphoreGive(dataMutex);
  String out; out.reserve(1536);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusAutomation().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishSunStatus() {
  DynamicJsonDocument doc(128);
  doc["sunrise"] = minutesToHHMM(g_sunriseMinute);
  doc["sunset"]  = minutesToHHMM(g_sunsetMinute);
  String out; out.reserve(128);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusSun().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishLocationStatus() {
  DynamicJsonDocument doc(128);
  doc["lat"] = g_latitude;
  doc["lon"] = g_longitude;
  String out; out.reserve(128);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusLocation().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishAlertSettings() {
  DynamicJsonDocument doc(320);
  doc["waEnabled"]         = g_alert.waEnabled;
  doc["waConfigured"]      = WA_ENABLED; // beri tahu dashboard apakah firmware sudah dikompilasi dengan WA aktif
  doc["tempHighEn"]        = g_alert.tempHighEn;
  doc["tempHighVal"]       = g_alert.tempHighVal;
  doc["tempLowEn"]         = g_alert.tempLowEn;
  doc["tempLowVal"]        = g_alert.tempLowVal;
  doc["humHighEn"]         = g_alert.humHighEn;
  doc["humHighVal"]        = g_alert.humHighVal;
  doc["humLowEn"]          = g_alert.humLowEn;
  doc["humLowVal"]         = g_alert.humLowVal;
  doc["relayStuckEn"]      = g_alert.relayStuckEn;
  doc["relayStuckMinutes"] = g_alert.relayStuckMinutes;
  String out; out.reserve(350);
  serializeJson(doc, out);
  mqttClient.publish(topicStatusAlertSettings().c_str(), (const uint8_t*)out.c_str(), out.length(), true);
}

void publishAllStatus() {
  publishSensorData();
  publishRelayStatus();
  publishTimerStatus();
  publishScheduleStatus();
  publishAutomationStatus();
  publishSunStatus();
  publishLocationStatus();
  publishAlertSettings();
}

// ------------------------------------------------------------------------
//  MQTT CALLBACK — menangani semua perintah dari dashboard
// ------------------------------------------------------------------------
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String t = String(topic);
  DynamicJsonDocument doc(1536);
  DeserializationError err = deserializeJson(doc, payload, length);
  if (err) return;

  if (t == topicCmdRelay()) {
    int relay = doc["relay"] | -1;
    bool state = doc["state"] | false;
    if (relay >= 1 && relay <= 4) {
      setRelay(relay - 1, state);
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      g_relayTimer[relay - 1].active = false;
      xSemaphoreGive(dataMutex);
      publishRelayStatus();
      publishTimerStatus();
    }
  }
  else if (t == topicCmdRelayTimer()) {
    int relay = doc["relay"] | -1;
    long duration = doc["duration"] | 0;
    bool state = doc["state"] | true;
    if (relay >= 1 && relay <= 4 && duration > 0) {
      DateTime now = rtc.now();
      setRelay(relay - 1, state);
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      g_relayTimer[relay - 1].active   = true;
      g_relayTimer[relay - 1].endEpoch = now.unixtime() + duration;
      g_relayTimer[relay - 1].revertTo = !state;
      xSemaphoreGive(dataMutex);
      publishRelayStatus();
      publishTimerStatus();
    }
  }
  else if (t == topicCmdScheduleSet()) {
    int idx = doc["index"] | -1;
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    if (idx < 0) {
      for (uint8_t i = 0; i < MAX_SCHEDULES; i++) {
        if (!g_schedules[i].used) { idx = i; break; }
      }
    }
    if (idx >= 0 && idx < MAX_SCHEDULES) {
      ScheduleItem &s = g_schedules[idx];
      s.used         = true;
      s.relay        = constrain((int)(doc["relay"] | 1) - 1, 0, 3);
      s.mode         = doc["mode"] | 0;
      s.onHour       = doc["onHour"] | 0;
      s.onMinute     = doc["onMinute"] | 0;
      s.offHour      = doc["offHour"] | 0;
      s.offMinute    = doc["offMinute"] | 0;
      s.onAnchor     = doc["onAnchor"] | 1;
      s.onOffsetMin  = doc["onOffsetMin"] | 0;
      s.offAnchor    = doc["offAnchor"] | 0;
      s.offOffsetMin = doc["offOffsetMin"] | 0;
      s.enabled      = doc["enabled"] | true;
      JsonArray days = doc["days"];
      if (!days.isNull()) {
        for (uint8_t d = 0; d < 7 && d < days.size(); d++) s.days[d] = days[d];
      }
      s.lastFiredMinuteOn  = -1;
      s.lastFiredMinuteOff = -1;
    }
    xSemaphoreGive(dataMutex);
    saveSchedulesToNVS();
    publishScheduleStatus();
  }
  else if (t == topicCmdScheduleDelete()) {
    int idx = doc["index"] | -1;
    if (idx >= 0 && idx < MAX_SCHEDULES) {
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      g_schedules[idx] = ScheduleItem();
      g_schedules[idx].used = false;
      xSemaphoreGive(dataMutex);
      saveSchedulesToNVS();
      publishScheduleStatus();
    }
  }
  else if (t == topicCmdAutomationSet()) {
    int idx = doc["index"] | -1;
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    if (idx < 0) {
      for (uint8_t i = 0; i < MAX_AUTOMATION_RULES; i++) {
        if (!g_rules[i].used) { idx = i; break; }
      }
    }
    if (idx >= 0 && idx < MAX_AUTOMATION_RULES) {
      AutomationRule &r = g_rules[idx];
      r.used        = true;
      const char* sensor = doc["sensor"] | "T";
      const char* oper   = doc["operator"] | ">";
      r.sensorType  = sensor[0];
      r.op          = oper[0];
      r.value       = doc["value"] | 30.0;
      r.relay       = constrain((int)(doc["relay"] | 1) - 1, 0, 3);
      r.targetState = doc["state"] | true;
      r.enabled     = doc["enabled"] | true;
    }
    xSemaphoreGive(dataMutex);
    saveRulesToNVS();
    publishAutomationStatus();
  }
  else if (t == topicCmdAutomationDelete()) {
    int idx = doc["index"] | -1;
    if (idx >= 0 && idx < MAX_AUTOMATION_RULES) {
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      g_rules[idx] = AutomationRule();
      g_rules[idx].used = false;
      xSemaphoreGive(dataMutex);
      saveRulesToNVS();
      publishAutomationStatus();
    }
  }
  else if (t == topicCmdRtcSet()) {
    long epoch = doc["epoch"] | 0;
    if (epoch > 0) {
      // Browser mengirim epoch UTC (standar Unix time). RTC di firmware ini
      // dipakai sebagai waktu LOKAL (semua perhitungan jadwal & matahari
      // mengasumsikan now.hour()/now.day() = waktu lokal WIB dsb), jadi
      // epoch UTC harus dikonversi dulu ke waktu lokal sebelum disimpan.
      uint32_t localEpoch = (uint32_t)epoch + (uint32_t)(TIMEZONE_OFFSET_HOURS * 3600L);
      rtc.adjust(DateTime(localEpoch));
      // Paksa hitung ulang jam matahari karena tanggal/waktu acuan berubah.
      g_sunCalcDay = -1; g_sunCalcMonth = -1;
      updateSunTimesIfNeeded(rtc.now());
      publishSensorData();
    }
  }
  else if (t == topicCmdLocationSet()) {
    g_latitude  = doc["lat"] | g_latitude;
    g_longitude = doc["lon"] | g_longitude;
    saveLocationToNVS();
    g_sunCalcDay = -1; g_sunCalcMonth = -1; // paksa hitung ulang jam matahari
    updateSunTimesIfNeeded(rtc.now());
    publishLocationStatus();
  }
  else if (t == topicCmdAlertSet()) {
    g_alert.waEnabled         = doc["waEnabled"] | g_alert.waEnabled;
    g_alert.tempHighEn        = doc["tempHighEn"] | false;
    g_alert.tempHighVal       = doc["tempHighVal"] | g_alert.tempHighVal;
    g_alert.tempLowEn         = doc["tempLowEn"] | false;
    g_alert.tempLowVal        = doc["tempLowVal"] | g_alert.tempLowVal;
    g_alert.humHighEn         = doc["humHighEn"] | false;
    g_alert.humHighVal        = doc["humHighVal"] | g_alert.humHighVal;
    g_alert.humLowEn          = doc["humLowEn"] | false;
    g_alert.humLowVal         = doc["humLowVal"] | g_alert.humLowVal;
    g_alert.relayStuckEn      = doc["relayStuckEn"] | false;
    g_alert.relayStuckMinutes = doc["relayStuckMinutes"] | g_alert.relayStuckMinutes;
    saveAlertToNVS();
    publishAlertSettings();
  }
  else if (t == topicCmdRequestStatus()) {
    publishAllStatus();
  }
}

// ------------------------------------------------------------------------
//  MQTT CONNECT / RECONNECT
// ------------------------------------------------------------------------
void reconnectMQTT() {
  static bool firstConnectDone = false;

  while (!mqttClient.connected()) {
    Serial.print("[MQTT] Menghubungkan ke broker EMQX...");
    String willTopic = topicStatusOnline();
    bool ok;
    if (strlen(MQTT_USERNAME) > 0) {
      ok = mqttClient.connect(MQTT_CLIENT_ID, MQTT_USERNAME, MQTT_PASSWORD,
                               willTopic.c_str(), 0, true, "offline");
    } else {
      ok = mqttClient.connect(MQTT_CLIENT_ID, willTopic.c_str(), 0, true, "offline");
    }

    if (ok) {
      Serial.println(" terhubung!");
      mqttClient.publish(willTopic.c_str(), "online", true);
      mqttClient.subscribe(topicCmdRelay().c_str());
      mqttClient.subscribe(topicCmdRelayTimer().c_str());
      mqttClient.subscribe(topicCmdScheduleSet().c_str());
      mqttClient.subscribe(topicCmdScheduleDelete().c_str());
      mqttClient.subscribe(topicCmdAutomationSet().c_str());
      mqttClient.subscribe(topicCmdAutomationDelete().c_str());
      mqttClient.subscribe(topicCmdRtcSet().c_str());
      mqttClient.subscribe(topicCmdLocationSet().c_str());
      mqttClient.subscribe(topicCmdAlertSet().c_str());
      mqttClient.subscribe(topicCmdRequestStatus().c_str());
      publishAllStatus();

      // Alert "perangkat online kembali" — dilewati saat koneksi PERTAMA setelah
      // booting supaya tidak kirim notifikasi tiap kali dinyalakan normal.
      if (firstConnectDone) {
        triggerAlert(ALERT_DEVICE_ONLINE, "device_online", "Perangkat kembali online setelah sempat terputus.");
      }
      firstConnectDone = true;
    } else {
      Serial.print(" gagal, rc="); Serial.print(mqttClient.state());
      Serial.println(" — coba lagi 3 detik lagi");
      vTaskDelay(pdMS_TO_TICKS(3000));
    }
  }
}

// ------------------------------------------------------------------------
//  TASK 1: WiFi + MQTT (core 0)
// ------------------------------------------------------------------------
void TaskWiFiMQTT(void *pv) {
  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("[WiFi] Terputus, menghubungkan ulang...");
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
      unsigned long start = millis();
      while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        vTaskDelay(pdMS_TO_TICKS(500));
      }
    }
    if (WiFi.status() == WL_CONNECTED) {
      if (!mqttClient.connected()) reconnectMQTT();
      mqttClient.loop();
    }

    static unsigned long lastPublish = 0;
    if (millis() - lastPublish > PUBLISH_INTERVAL_MS) {
      lastPublish = millis();
      if (mqttClient.connected()) {
        publishSensorData();
        publishRelayStatus();
        publishTimerStatus();
        if (g_needPublishSchedule)   { publishScheduleStatus();   g_needPublishSchedule = false; }
        if (g_needPublishAutomation) { publishAutomationStatus(); g_needPublishAutomation = false; }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// ------------------------------------------------------------------------
//  TASK 2: Baca sensor DHT22 (core 1)
// ------------------------------------------------------------------------
void TaskSensor(void *pv) {
  for (;;) {
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    if (!isnan(h) && !isnan(t)) {
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      g_sensor.temperature = t;
      g_sensor.humidity    = h;
      g_sensor.valid        = true;
      xSemaphoreGive(dataMutex);
    } else {
      Serial.println("[DHT22] Gagal membaca sensor!");
    }
    vTaskDelay(pdMS_TO_TICKS(SENSOR_READ_INTERVAL_MS));
  }
}

// ------------------------------------------------------------------------
//  TASK 3: Scheduler — jadwal (tetap & matahari), automation rules,
//  relay timer, dan pengecekan alert. (core 1)
// ------------------------------------------------------------------------
void TaskScheduler(void *pv) {
  for (;;) {
    DateTime now = rtc.now();
    updateSunTimesIfNeeded(now);

    bool relayChanged = false;
    bool timerChanged = false;

    // ---- 1. Cek relay timer (matikan/nyalakan otomatis setelah durasi) ----
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    for (uint8_t i = 0; i < 4; i++) {
      if (g_relayTimer[i].active && now.unixtime() >= g_relayTimer[i].endEpoch) {
        setRelayNoLock(i, g_relayTimer[i].revertTo, now);
        g_relayTimer[i].active = false;
        relayChanged = true;
        timerChanged = true;
      }
    }
    xSemaphoreGive(dataMutex);

    // ---- 2. Cek jadwal (jam tetap ATAU berdasarkan matahari) ----
    int wd = now.dayOfTheWeek(); // 0=Minggu..6=Sabtu
    int curMinuteOfDay = now.hour() * 60 + now.minute();
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    for (uint8_t i = 0; i < MAX_SCHEDULES; i++) {
      ScheduleItem &s = g_schedules[i];
      if (!s.used || !s.enabled || s.relay > 3 || !s.days[wd]) continue;

      int onMin, offMin;
      if (s.mode == 1) {
        onMin  = ((scheduleAnchorMinute(s.onAnchor)  + s.onOffsetMin)  % 1440 + 1440) % 1440;
        offMin = ((scheduleAnchorMinute(s.offAnchor) + s.offOffsetMin) % 1440 + 1440) % 1440;
      } else {
        onMin  = s.onHour * 60 + s.onMinute;
        offMin = s.offHour * 60 + s.offMinute;
      }

      if (curMinuteOfDay == onMin && s.lastFiredMinuteOn != curMinuteOfDay) {
        setRelayNoLock(s.relay, true, now);
        s.lastFiredMinuteOn = curMinuteOfDay;
        relayChanged = true;
      }
      if (curMinuteOfDay == offMin && s.lastFiredMinuteOff != curMinuteOfDay) {
        setRelayNoLock(s.relay, false, now);
        s.lastFiredMinuteOff = curMinuteOfDay;
        relayChanged = true;
      }
    }
    xSemaphoreGive(dataMutex);

    // ---- 3. Cek automation rules (berbasis suhu/kelembaban) ----
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    SensorData s = g_sensor;
    for (uint8_t i = 0; i < MAX_AUTOMATION_RULES; i++) {
      AutomationRule &r = g_rules[i];
      if (!r.used || !r.enabled || !s.valid || r.relay > 3) continue;
      float val = (r.sensorType == 'H') ? s.humidity : s.temperature;
      bool cond = (r.op == '>') ? (val > r.value) : (val < r.value);
      if (cond && !r.lastTriggered) {
        setRelayNoLock(r.relay, r.targetState, now);
        relayChanged = true;
      }
      r.lastTriggered = cond;
    }
    xSemaphoreGive(dataMutex);

    // ---- 4. Cek alert suhu / kelembaban ekstrem ----
    if (s.valid) {
      if (g_alert.tempHighEn && s.temperature > g_alert.tempHighVal)
        triggerAlert(ALERT_TEMP_HIGH, "temp_high",
          "Suhu tinggi: " + String(s.temperature, 1) + " C (ambang " + String(g_alert.tempHighVal, 1) + " C)");
      if (g_alert.tempLowEn && s.temperature < g_alert.tempLowVal)
        triggerAlert(ALERT_TEMP_LOW, "temp_low",
          "Suhu rendah: " + String(s.temperature, 1) + " C (ambang " + String(g_alert.tempLowVal, 1) + " C)");
      if (g_alert.humHighEn && s.humidity > g_alert.humHighVal)
        triggerAlert(ALERT_HUM_HIGH, "hum_high",
          "Kelembaban tinggi: " + String(s.humidity, 1) + "% (ambang " + String(g_alert.humHighVal, 1) + "%)");
      if (g_alert.humLowEn && s.humidity < g_alert.humLowVal)
        triggerAlert(ALERT_HUM_LOW, "hum_low",
          "Kelembaban rendah: " + String(s.humidity, 1) + "% (ambang " + String(g_alert.humLowVal, 1) + "%)");
    }

    // ---- 5. Cek relay macet (menyala lebih lama dari batas) ----
    if (g_alert.relayStuckEn) {
      for (uint8_t i = 0; i < 4; i++) {
        xSemaphoreTake(dataMutex, portMAX_DELAY);
        uint32_t onSince = g_relayOnSinceEpoch[i];
        xSemaphoreGive(dataMutex);
        if (onSince != 0) {
          uint32_t elapsedMin = (now.unixtime() - onSince) / 60;
          if (elapsedMin >= g_alert.relayStuckMinutes) {
            triggerAlert(ALERT_RELAY_STUCK_BASE + i, "relay_stuck",
              "Relay " + String(i + 1) + " sudah menyala lebih dari " + String(g_alert.relayStuckMinutes) + " menit");
          }
        }
      }
    }

    if (relayChanged && mqttClient.connected()) publishRelayStatus();
    if (timerChanged && mqttClient.connected()) publishTimerStatus();

    vTaskDelay(pdMS_TO_TICKS(SCHEDULER_TICK_MS));
  }
}

// ------------------------------------------------------------------------
//  SETUP
// ------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== ESP32 Relay + DHT22 + DS3231 (FreeRTOS + MQTT) ===");

  // --- Pin relay ---
  for (uint8_t i = 0; i < 4; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    applyRelayPin(i, false); // pastikan semua relay OFF saat boot
  }

  // --- DHT22 ---
  dht.begin();

  // --- DS3231 ---
  Wire.begin();
  if (!rtc.begin()) {
    Serial.println("[RTC] DS3231 tidak terdeteksi! Periksa wiring SDA/SCL.");
  }
  if (rtc.lostPower()) {
    Serial.println("[RTC] Baterai habis/waktu hilang, set waktu ke waktu kompilasi.");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  // --- Mutex ---
  dataMutex = xSemaphoreCreateMutex();

  // --- Load data tersimpan ---
  loadSchedulesFromNVS();
  loadRulesFromNVS();
  loadLocationFromNVS();
  loadAlertFromNVS();
  updateSunTimesIfNeeded(rtc.now());

  // --- WiFi ---
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  // --- MQTT ---
  if (MQTT_USE_TLS) {
    wifiClientSecure.setInsecure(); // tanpa verifikasi sertifikat (untuk kemudahan; untuk produksi tambahkan CA cert EMQX)
  }
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setBufferSize(4096); // payload jadwal/automation cukup besar

  // --- FreeRTOS Tasks ---
  xTaskCreatePinnedToCore(TaskWiFiMQTT, "WiFiMQTT",  10240, NULL, 2, NULL, 0);
  xTaskCreatePinnedToCore(TaskSensor,   "Sensor",    4096,  NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(TaskScheduler,"Scheduler", 8192,  NULL, 1, NULL, 1);

  Serial.println("Setup selesai. Task FreeRTOS berjalan.");
}

// loop() sengaja dikosongkan karena semua pekerjaan sudah ditangani task FreeRTOS
void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));
}
