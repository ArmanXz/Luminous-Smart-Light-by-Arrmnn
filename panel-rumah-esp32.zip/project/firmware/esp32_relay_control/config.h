/*
 * config.h
 * -------------------------------------------------------
 * Semua pengaturan yang perlu diubah sesuai kebutuhanmu
 * ada di file ini. File .ino TIDAK PERLU diubah.
 * -------------------------------------------------------
 */
#ifndef CONFIG_H
#define CONFIG_H

// ============ WIFI ============
#define WIFI_SSID         "NAMA_WIFI_ANDA"
#define WIFI_PASSWORD     "PASSWORD_WIFI_ANDA"

// ============ MQTT BROKER (EMQX) ============
// Gunakan salah satu:
//  - EMQX Public Test Broker (gratis, tanpa auth, TANPA TLS) -> untuk testing cepat
//      host: broker.emqx.io   port: 1883
//  - EMQX Cloud Serverless (gratis, perlu daftar di emqx.com, pakai TLS)
//      host: xxxxxx.emqxsl.com   port: 8883 (TLS)
#define MQTT_HOST         "broker.emqx.io"
#define MQTT_PORT         1883          // 8883 jika TLS (EMQX Cloud)
#define MQTT_USE_TLS      false         // set true jika pakai EMQX Cloud + port 8883
#define MQTT_USERNAME     ""            // isi jika broker butuh login
#define MQTT_PASSWORD     ""            // isi jika broker butuh login
#define MQTT_CLIENT_ID    "esp32-relay-01"   // harus unik, ganti jika ada lebih dari 1 device

// Prefix topic. Dashboard web juga harus diset dengan prefix yang sama
// di tab Pengaturan agar bisa saling komunikasi.
#define TOPIC_PREFIX      "rumah/esp32-relay-01"

// ============ LOKASI (untuk Jadwal Berdasarkan Matahari) ============
// Isi koordinat lokasi Anda (di Google Maps: klik-kanan pada lokasi ->
// koordinat akan muncul dan bisa disalin). Nilai ini hanya default awal;
// koordinat juga bisa diubah langsung dari dashboard (tab Setting) tanpa
// perlu upload ulang firmware.
#define DEFAULT_LATITUDE   -6.2088    // contoh: Jakarta
#define DEFAULT_LONGITUDE  106.8456

// ============ ALERT WHATSAPP (opsional) ============
// Menggunakan CallMeBot (gratis, tanpa server tambahan):
// https://www.callmebot.com/blog/free-api-whatsapp-messages/
// 1. Simpan nomor CallMeBot ke kontak WhatsApp Anda, kirim pesan aktivasi
//    sesuai instruksi di situs mereka
// 2. Anda akan menerima API key pribadi lewat balasan WhatsApp
// 3. Isi nomor & API key di bawah ini
#define WA_ENABLED         false            // set true untuk mengaktifkan pengiriman WhatsApp dari ESP32
#define WA_PHONE           "62812xxxxxxx"   // format internasional TANPA tanda +
#define WA_APIKEY          "123456"         // API key dari CallMeBot

// ============ PIN ============
#define RELAY1_PIN        16
#define RELAY2_PIN        17
#define RELAY3_PIN        18
#define RELAY4_PIN        19
#define DHT_PIN           4
#define DHT_TYPE          DHT22

// Sebagian modul relay aktif LOW (mengaktifkan relay saat pin diberi LOW).
// Set true jika modul relaymu jenis "active LOW" (paling umum untuk modul 5V/3.3V relay board).
#define RELAY_ACTIVE_LOW  true

// ============ LAIN-LAIN ============
#define SENSOR_READ_INTERVAL_MS   2000     // interval baca DHT22
#define PUBLISH_INTERVAL_MS       3000     // interval publish status ke MQTT
#define SCHEDULER_TICK_MS         1000     // interval cek jadwal/otomasi/timer
#define MAX_SCHEDULES             10
#define MAX_AUTOMATION_RULES      10

// Zona waktu untuk DS3231 (hanya dipakai untuk referensi, RTC tetap simpan waktu lokal)
#define TIMEZONE_OFFSET_HOURS     7   // WIB = UTC+7

// Jeda minimum antar pengiriman alert dengan tipe yang sama (detik), supaya
// tidak spam notifikasi/WhatsApp saat kondisi terus-menerus terpenuhi.
#define ALERT_COOLDOWN_SEC        1800   // 30 menit

#endif
