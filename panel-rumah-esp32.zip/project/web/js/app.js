/* =========================================================================
   PANEL RUMAH — app.js
   Menghubungkan dashboard ke ESP32 lewat MQTT broker EMQX (WebSocket)
   ========================================================================= */

// -------------------------------------------------------------------------
// 1. KONFIGURASI & STATE
// -------------------------------------------------------------------------
const DEFAULT_CONFIG = {
  host: 'broker.emqx.io',
  port: 8083,
  protocol: 'ws',        // 'ws' atau 'wss'
  path: '/mqtt',
  username: '',
  password: '',
  prefix: 'rumah/esp32-relay-01'
};

const DEFAULT_RELAY_META = [
  { name: 'Lampu Ruang Tamu', icon: 'la-lightbulb' },
  { name: 'Kipas Angin',      icon: 'la-fan' },
  { name: 'Pompa Air',        icon: 'la-tint' },
  { name: 'Stop Kontak',      icon: 'la-plug' }
];

const ICON_OPTIONS = [
  { icon: 'la-lightbulb', label: 'Lampu' },
  { icon: 'la-fan',       label: 'Kipas' },
  { icon: 'la-tint',      label: 'Pompa Air' },
  { icon: 'la-plug',      label: 'Stop Kontak' },
  { icon: 'la-snowflake', label: 'AC' },
  { icon: 'la-video',     label: 'CCTV' },
  { icon: 'la-warehouse', label: 'Gerbang / Garasi' },
  { icon: 'la-toggle-on', label: 'Lainnya' }
];

const DAY_LABELS_SHORT = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'];

let cfg = loadJSON('mqttConfig', DEFAULT_CONFIG);
let relayMeta = loadJSON('relayMeta', DEFAULT_RELAY_META);

let state = {
  sensor: { temperature: null, humidity: null, time: '--:--:--', date: '--/--/----' },
  relay: [false, false, false, false],
  timer: [{active:false,remaining:0},{active:false,remaining:0},{active:false,remaining:0},{active:false,remaining:0}],
  schedules: [],
  rules: [],
  sun: { sunrise: '--:--', sunset: '--:--' },
  location: { lat: null, lon: null },
  alertSettings: {
    waEnabled: false, waConfigured: false,
    tempHighEn: false, tempHighVal: 35,
    tempLowEn: false, tempLowVal: 10,
    humHighEn: false, humHighVal: 80,
    humLowEn: false, humLowVal: 20,
    relayStuckEn: false, relayStuckMinutes: 180
  }
};

let alertLog = loadJSON('alertLog', []); // [{type,message,time,epoch}], terbaru di depan

const DEFAULT_BG_SETTINGS = { type: 'none', url: '', overlay: 55, blur: true };
let bgSettings = loadJSON('bgSettings', DEFAULT_BG_SETTINGS);
let bgImageData = null; // dataURL hasil upload, dimuat async dari localStorage saat init

let history = loadJSON('sensorHistory', []); // [{t:'HH:MM',temp,hum}]
let chartRangeCount = 30;
let editingScheduleIndex = null;
let editingRuleIndex = null;
let activeTimerRelay = null;

let mqttClient = null;

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
function saveJSON(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

// -------------------------------------------------------------------------
// 2. TOPIC HELPERS
// -------------------------------------------------------------------------
const T = {
  cmdRelay: () => `${cfg.prefix}/cmd/relay`,
  cmdRelayTimer: () => `${cfg.prefix}/cmd/relay_timer`,
  cmdScheduleSet: () => `${cfg.prefix}/cmd/schedule_set`,
  cmdScheduleDelete: () => `${cfg.prefix}/cmd/schedule_delete`,
  cmdAutomationSet: () => `${cfg.prefix}/cmd/automation_set`,
  cmdAutomationDelete: () => `${cfg.prefix}/cmd/automation_delete`,
  cmdRtcSet: () => `${cfg.prefix}/cmd/rtc_set`,
  cmdLocationSet: () => `${cfg.prefix}/cmd/location_set`,
  cmdAlertSet: () => `${cfg.prefix}/cmd/alert_set`,
  cmdRequestStatus: () => `${cfg.prefix}/cmd/request_status`,
  statusAll: () => `${cfg.prefix}/status/#`
};

// -------------------------------------------------------------------------
// 3. MQTT CONNECTION
// -------------------------------------------------------------------------
function connectMQTT() {
  if (mqttClient) {
    try { mqttClient.end(true); } catch (e) {}
  }
  setConnState('connecting', 'Menghubungkan\u2026');

  const url = `${cfg.protocol}://${cfg.host}:${cfg.port}${cfg.path}`;
  const options = {
    clientId: 'dashboard-' + Math.random().toString(16).slice(2, 10),
    username: cfg.username || undefined,
    password: cfg.password || undefined,
    reconnectPeriod: 4000,
    connectTimeout: 8000,
    clean: true
  };

  try {
    mqttClient = mqtt.connect(url, options);
  } catch (e) {
    setConnState('offline', 'Konfigurasi salah');
    return;
  }

  mqttClient.on('connect', () => {
    setConnState('online', 'Terhubung ke broker');
    mqttClient.subscribe(T.statusAll());
    mqttClient.publish(T.cmdRequestStatus(), '{}');
  });
  mqttClient.on('reconnect', () => setConnState('connecting', 'Menyambung ulang\u2026'));
  mqttClient.on('close', () => setConnState('offline', 'Terputus dari broker'));
  mqttClient.on('error', () => setConnState('offline', 'Gagal terhubung'));
  mqttClient.on('message', onMqttMessage);
}

function setConnState(stateKey, text) {
  const pill = document.getElementById('connPill');
  pill.dataset.state = stateKey;
  document.getElementById('connText').textContent = text;
}

function onMqttMessage(topic, payloadBuf) {
  let payload;
  try { payload = JSON.parse(payloadBuf.toString()); } catch (e) { return; }

  try {
    if (topic.endsWith('/status/sensor')) {
      state.sensor = payload;
      document.getElementById('deviceSubtitle').textContent = 'ESP32 \u00b7 Online';
      // Render angka suhu/kelembaban/jam DULU dan tanpa syarat — ini yang
      // paling penting dan tidak boleh gagal hanya karena grafik bermasalah
      // (mis. Chart.js belum siap/gagal dimuat dari CDN).
      renderSensor();
      try { pushHistory(payload); } catch (e) { console.error('[chart] gagal update riwayat', e); }
    } else if (topic.endsWith('/status/relay')) {
      state.relay = [payload.relay1, payload.relay2, payload.relay3, payload.relay4];
      renderRelayGrid();
    } else if (topic.endsWith('/status/timer')) {
      for (let i = 0; i < 4; i++) {
        const o = payload['relay' + (i + 1)];
        if (o) state.timer[i] = o;
      }
      renderRelayGrid();
    } else if (topic.endsWith('/status/schedule')) {
      state.schedules = payload;
      renderScheduleList();
    } else if (topic.endsWith('/status/automation')) {
      state.rules = payload;
      renderRuleList();
    } else if (topic.endsWith('/status/online')) {
      document.getElementById('deviceSubtitle').textContent =
        'ESP32 \u00b7 ' + (payloadBuf.toString() === 'online' ? 'Online' : 'Offline');
    } else if (topic.endsWith('/status/sun')) {
      state.sun = payload;
      renderSunInfo();
    } else if (topic.endsWith('/status/location')) {
      state.location = payload;
      fillLocationForm();
    } else if (topic.endsWith('/status/alert_settings')) {
      state.alertSettings = payload;
      fillAlertForm();
    } else if (topic.endsWith('/status/alert')) {
      handleIncomingAlert(payload);
    }
  } catch (e) {
    console.error('[mqtt] gagal memproses pesan', topic, e);
  }
}

function renderSunInfo() {
  document.getElementById('sunriseVal').textContent = state.sun.sunrise || '--:--';
  document.getElementById('sunsetVal').textContent = state.sun.sunset || '--:--';
  const srRef = document.getElementById('schSunriseRef');
  const ssRef = document.getElementById('schSunsetRef');
  if (srRef) srRef.textContent = state.sun.sunrise || '--:--';
  if (ssRef) ssRef.textContent = state.sun.sunset || '--:--';
  const locSr = document.getElementById('locSunrise');
  const locSs = document.getElementById('locSunset');
  if (locSr) locSr.textContent = state.sun.sunrise || '--:--';
  if (locSs) locSs.textContent = state.sun.sunset || '--:--';
}

function handleIncomingAlert(payload) {
  // simpan ke riwayat (maks 20, terbaru di depan)
  alertLog.unshift(payload);
  if (alertLog.length > 20) alertLog = alertLog.slice(0, 20);
  saveJSON('alertLog', alertLog);
  renderAlertLog();

  showToast(payload.message, true);

  if (localStorage.getItem('notifBrowserEnabled') === 'true' &&
      typeof Notification !== 'undefined' && Notification.permission === 'granted') {
    try {
      new Notification('Panel Rumah \u2014 Alert', { body: payload.message, tag: payload.type });
    } catch (e) { /* abaikan bila browser menolak */ }
  }
}

function pushHistory(sensorData) {
  if (sensorData.temperature == null || sensorData.humidity == null) return;
  history.push({ t: sensorData.time ? sensorData.time.slice(0,5) : '', temp: sensorData.temperature, hum: sensorData.humidity });
  if (history.length > 200) history = history.slice(history.length - 200);
  saveJSON('sensorHistory', history);
  updateChart();
}

// -------------------------------------------------------------------------
// 4. RENDER: SENSOR & CLOCK
// -------------------------------------------------------------------------
const GAUGE_CIRC = 326.7;
function renderSensor() {
  const t = state.sensor.temperature, h = state.sensor.humidity;
  document.getElementById('valSuhu').textContent = (t != null) ? t.toFixed(1) : '--';
  document.getElementById('valLembab').textContent = (h != null) ? h.toFixed(1) : '--';
  document.getElementById('rtcTime').textContent = state.sensor.time || '--:--:--';
  document.getElementById('rtcDate').textContent = state.sensor.date || '--/--/----';

  const tempPct = t != null ? Math.max(0, Math.min(1, t / 50)) : 0;
  const humPct  = h != null ? Math.max(0, Math.min(1, h / 100)) : 0;
  document.getElementById('gaugeSuhu').style.strokeDashoffset = GAUGE_CIRC * (1 - tempPct);
  document.getElementById('gaugeLembab').style.strokeDashoffset = GAUGE_CIRC * (1 - humPct);
}

// -------------------------------------------------------------------------
// 5. RENDER: RELAY GRID
// -------------------------------------------------------------------------
function renderRelaySelects() {
  ['schRelay', 'ruleRelay'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = relayMeta.map((m, i) => `<option value="${i}">${escapeHtml(m.name)}</option>`).join('');
  });
}

function renderRelayGrid() {
  const grid = document.getElementById('relayGrid');
  grid.innerHTML = relayMeta.map((meta, i) => {
    const on = !!state.relay[i];
    const tm = state.timer[i];
    return `
    <div class="relay-card ${on ? 'is-on' : ''}" data-relay="${i}">
      <div class="relay-card__top">
        <div class="relay-card__icon"><i class="las ${meta.icon}"></i></div>
        <button class="toggle" data-toggle="${i}" aria-label="Toggle relay"><span class="toggle__knob"></span></button>
      </div>
      <div class="relay-card__name">${escapeHtml(meta.name)}</div>
      <div class="relay-card__meta">
        <span class="relay-card__status">${on ? 'Menyala' : 'Mati'}</span>
        <button class="relay-card__timerbtn" data-timerbtn="${i}"><i class="las la-stopwatch"></i></button>
      </div>
      <div class="relay-card__timer" ${tm.active ? '' : 'hidden'} data-timerlabel="${i}">
        <i class="las la-hourglass-half"></i> Auto-ubah dalam ${formatDuration(tm.remaining)}
      </div>
    </div>`;
  }).join('');

  grid.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.toggle;
      const newState = !state.relay[idx];
      state.relay[idx] = newState; // optimistic UI
      renderRelayGrid();
      publishJSON(T.cmdRelay(), { relay: idx + 1, state: newState });
    });
  });
  grid.querySelectorAll('[data-timerbtn]').forEach(btn => {
    btn.addEventListener('click', () => openTimerModal(+btn.dataset.timerbtn));
  });
}

function formatDuration(sec) {
  sec = Math.max(0, sec | 0);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  if (h > 0) return `${h}j ${m}m`;
  if (m > 0) return `${m}m ${s}d`;
  return `${s}d`;
}

// countdown lokal supaya angka berjalan tiap detik tanpa menunggu MQTT
setInterval(() => {
  let changed = false;
  state.timer.forEach(t => {
    if (t.active && t.remaining > 0) { t.remaining--; changed = true; }
  });
  if (changed) {
    document.querySelectorAll('[data-timerlabel]').forEach(el => {
      const idx = +el.dataset.timerlabel;
      const t = state.timer[idx];
      if (t.active) {
        el.innerHTML = `<i class="las la-hourglass-half"></i> Auto-ubah dalam ${formatDuration(t.remaining)}`;
      }
    });
  }
}, 1000);

// -------------------------------------------------------------------------
// 6. RENDER: JADWAL & RULES
// -------------------------------------------------------------------------
function fixedLabel(s) {
  const on = String(s.onHour).padStart(2,'0') + ':' + String(s.onMinute).padStart(2,'0');
  const off = String(s.offHour).padStart(2,'0') + ':' + String(s.offMinute).padStart(2,'0');
  return `${on} &ndash; ${off}`;
}
function astroLabel(s) {
  const onAnchor = s.onAnchor == 0 ? 'Terbit' : 'Terbenam';
  const offAnchor = s.offAnchor == 0 ? 'Terbit' : 'Terbenam';
  return `${onAnchor}${offsetSuffix(s.onOffsetMin)} &rarr; ${offAnchor}${offsetSuffix(s.offOffsetMin)}`;
}
function offsetSuffix(min) {
  if (!min) return '';
  return min > 0 ? ` +${min}m` : ` ${min}m`;
}

function renderScheduleList() {
  const list = document.getElementById('scheduleList');
  const empty = document.getElementById('scheduleEmpty');
  if (!state.schedules.length) {
    list.innerHTML = '';
    list.appendChild(empty);
    empty.hidden = false;
    return;
  }
  empty.hidden = true;
  list.innerHTML = state.schedules.map(s => {
    const meta = relayMeta[s.relay] || { name: 'Relay ' + (s.relay + 1) };
    const days = s.days.map((d, i) => d ? DAY_LABELS_SHORT[i] : null).filter(Boolean).join(', ');
    const timeLabel = (s.mode == 1) ? astroLabel(s) : fixedLabel(s);
    return `
    <div class="item-card ${s.enabled ? '' : 'is-disabled'}">
      <div class="item-card__icon"><i class="las ${s.mode == 1 ? 'la-sun' : 'la-calendar-check'}"></i></div>
      <div class="item-card__body">
        <div class="item-card__title">${escapeHtml(meta.name)} \u00b7 ${timeLabel}</div>
        <div class="item-card__sub">${days || 'Tidak ada hari dipilih'}</div>
      </div>
      <div class="item-card__actions">
        <button class="mini-switch ${s.enabled ? 'is-on' : ''}" data-sch-toggle="${s.index}"><span class="mini-switch__knob"></span></button>
        <button class="chip-btn" data-sch-edit="${s.index}"><i class="las la-edit"></i></button>
        <button class="chip-btn chip-btn--danger" data-sch-del="${s.index}"><i class="las la-trash"></i></button>
      </div>
    </div>`;
  }).join('');

  list.querySelectorAll('[data-sch-toggle]').forEach(b => b.addEventListener('click', () => {
    const s = state.schedules.find(x => x.index == b.dataset.schToggle);
    publishJSON(T.cmdScheduleSet(), { ...s, enabled: !s.enabled });
  }));
  list.querySelectorAll('[data-sch-edit]').forEach(b => b.addEventListener('click', () => {
    openScheduleModal(state.schedules.find(x => x.index == b.dataset.schEdit));
  }));
  list.querySelectorAll('[data-sch-del]').forEach(b => b.addEventListener('click', () => {
    if (confirm('Hapus jadwal ini?')) publishJSON(T.cmdScheduleDelete(), { index: +b.dataset.schDel });
  }));
}

function renderRuleList() {
  const list = document.getElementById('ruleList');
  const empty = document.getElementById('ruleEmpty');
  if (!state.rules.length) {
    list.innerHTML = '';
    list.appendChild(empty);
    empty.hidden = false;
    return;
  }
  empty.hidden = true;
  list.innerHTML = state.rules.map(r => {
    const meta = relayMeta[r.relay] || { name: 'Relay ' + (r.relay + 1) };
    const sensorLabel = r.sensor === 'H' ? 'Kelembaban' : 'Suhu';
    const unit = r.sensor === 'H' ? '%' : '\u00b0C';
    const icon = r.sensor === 'H' ? 'la-tint' : 'la-thermometer-half';
    return `
    <div class="item-card ${r.enabled ? '' : 'is-disabled'}">
      <div class="item-card__icon"><i class="las ${icon}"></i></div>
      <div class="item-card__body">
        <div class="item-card__title">${sensorLabel} ${r.operator} ${r.value}${unit} &rarr; ${escapeHtml(meta.name)} ${r.state ? 'ON' : 'OFF'}</div>
        <div class="item-card__sub">${r.enabled ? 'Aktif' : 'Nonaktif'}</div>
      </div>
      <div class="item-card__actions">
        <button class="mini-switch ${r.enabled ? 'is-on' : ''}" data-rule-toggle="${r.index}"><span class="mini-switch__knob"></span></button>
        <button class="chip-btn" data-rule-edit="${r.index}"><i class="las la-edit"></i></button>
        <button class="chip-btn chip-btn--danger" data-rule-del="${r.index}"><i class="las la-trash"></i></button>
      </div>
    </div>`;
  }).join('');

  list.querySelectorAll('[data-rule-toggle]').forEach(b => b.addEventListener('click', () => {
    const r = state.rules.find(x => x.index == b.dataset.ruleToggle);
    publishJSON(T.cmdAutomationSet(), { ...r, enabled: !r.enabled });
  }));
  list.querySelectorAll('[data-rule-edit]').forEach(b => b.addEventListener('click', () => {
    openRuleModal(state.rules.find(x => x.index == b.dataset.ruleEdit));
  }));
  list.querySelectorAll('[data-rule-del]').forEach(b => b.addEventListener('click', () => {
    if (confirm('Hapus rule ini?')) publishJSON(T.cmdAutomationDelete(), { index: +b.dataset.ruleDel });
  }));
}

function renderAlertLog() {
  const list = document.getElementById('alertLogList');
  const empty = document.getElementById('alertLogEmpty');
  if (!list) return;
  if (!alertLog.length) {
    list.innerHTML = '';
    list.appendChild(empty);
    empty.hidden = false;
    return;
  }
  empty.hidden = true;
  const ICONS = {
    temp_high: 'la-thermometer-full', temp_low: 'la-thermometer-empty',
    hum_high: 'la-tint', hum_low: 'la-tint-slash',
    relay_stuck: 'la-exclamation-triangle', device_online: 'la-plug'
  };
  list.innerHTML = alertLog.map(a => `
    <div class="item-card alert-item">
      <div class="item-card__icon"><i class="las ${ICONS[a.type] || 'la-bell'}"></i></div>
      <div class="item-card__body">
        <div class="item-card__title">${escapeHtml(a.message)}</div>
        <div class="item-card__sub">${escapeHtml(a.time || '')}</div>
      </div>
    </div>`).join('');
}
document.getElementById('btnClearAlertLog').addEventListener('click', () => {
  if (!confirm('Hapus semua riwayat alert?')) return;
  alertLog = [];
  saveJSON('alertLog', alertLog);
  renderAlertLog();
  showToast('Riwayat alert dihapus');
});

// -------------------------------------------------------------------------
// 7. CHART
// -------------------------------------------------------------------------
let chart;
function initChart() {
  if (typeof Chart === 'undefined') {
    console.error('[chart] Library Chart.js belum termuat (CDN gagal/lambat) — grafik dilewati, fitur lain tetap jalan.');
    return;
  }
  const ctx = document.getElementById('sensorChart').getContext('2d');
  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [
        { label: 'Suhu (\u00b0C)', data: [], borderColor: '#5B6EF5', backgroundColor: 'rgba(91,110,245,.12)',
          tension: .35, fill: true, pointRadius: 0, borderWidth: 2, yAxisID: 'y' },
        { label: 'Kelembaban (%)', data: [], borderColor: '#00C9A7', backgroundColor: 'rgba(0,201,167,.10)',
          tension: .35, fill: true, pointRadius: 0, borderWidth: 2, yAxisID: 'y1' }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: { legend: { labels: { boxWidth: 10, font: { size: 11 } } } },
      scales: {
        y:  { position: 'left', ticks: { font: { size: 10 } }, grid: { color: 'rgba(150,150,150,.12)' } },
        y1: { position: 'right', ticks: { font: { size: 10 } }, grid: { display: false } },
        x:  { ticks: { font: { size: 9 }, maxRotation: 0 }, grid: { display: false } }
      }
    }
  });
  updateChart();
}
function updateChart() {
  if (!chart) return; // Chart.js belum siap/gagal dimuat — lewati saja, jangan sampai error
  const slice = history.slice(-chartRangeCount);
  chart.data.labels = slice.map(d => d.t);
  chart.data.datasets[0].data = slice.map(d => d.temp);
  chart.data.datasets[1].data = slice.map(d => d.hum);
  chart.update();
}

// -------------------------------------------------------------------------
// 8. TABS + FLOATING DOCK
// -------------------------------------------------------------------------
function initTabs() {
  const buttons = document.querySelectorAll('.dock__btn');
  const indicator = document.getElementById('dockIndicator');

  function moveIndicator(btn) {
    indicator.style.width = btn.offsetWidth + 'px';
    indicator.style.transform = `translateX(${btn.offsetLeft - 8}px)`;
  }
  function activate(tabId, btn) {
    document.querySelectorAll('[data-panel]').forEach(p => p.hidden = (p.id !== tabId));
    buttons.forEach(b => b.classList.toggle('is-active', b === btn));
    moveIndicator(btn);
  }
  buttons.forEach(btn => btn.addEventListener('click', () => activate(btn.dataset.tab, btn)));
  window.addEventListener('resize', () => moveIndicator(document.querySelector('.dock__btn.is-active')));
  window.addEventListener('orientationchange', () => moveIndicator(document.querySelector('.dock__btn.is-active')));
  // posisi awal, lalu dihitung ulang setelah font ikon/teks selesai dimuat
  // (lebar tombol bisa berubah saat font baru selesai render)
  setTimeout(() => moveIndicator(document.querySelector('.dock__btn.is-active')), 60);
  window.addEventListener('load', () => moveIndicator(document.querySelector('.dock__btn.is-active')));
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => moveIndicator(document.querySelector('.dock__btn.is-active')));
  }
}

// -------------------------------------------------------------------------
// 8b. STICKY SUMMARY BORDER (garis halus muncul saat sudah menempel)
// -------------------------------------------------------------------------
function initStickySummaryObserver() {
  const sentinel = document.getElementById('stickySentinel');
  const summary = document.getElementById('stickySummary');
  if (!sentinel || !summary || typeof IntersectionObserver === 'undefined') return;
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        summary.classList.toggle('is-stuck', !entry.isIntersecting);
      });
    },
    { threshold: 0 }
  );
  observer.observe(sentinel);
}

// -------------------------------------------------------------------------
// 9. THEME
// -------------------------------------------------------------------------
function initTheme() {
  const saved = localStorage.getItem('theme') || 'light';
  applyTheme(saved);
  document.getElementById('themeToggle').addEventListener('click', () => {
    applyTheme(document.body.dataset.theme === 'light' ? 'dark' : 'light');
  });
  document.querySelectorAll('[data-theme-pick]').forEach(b => {
    b.addEventListener('click', () => applyTheme(b.dataset.themePick));
  });
}
function applyTheme(theme) {
  document.body.dataset.theme = theme;
  localStorage.setItem('theme', theme);
  document.getElementById('themeIcon').className = 'las ' + (theme === 'dark' ? 'la-sun' : 'la-moon');
  if (typeof applyBackgroundSettings === 'function') applyBackgroundSettings();
}

// -------------------------------------------------------------------------
// 10. MODALS
// -------------------------------------------------------------------------
function openModal(id) { document.getElementById(id).hidden = false; }
function closeModal(id) { document.getElementById(id).hidden = true; }

// --- Timer modal ---
function openTimerModal(relayIdx) {
  activeTimerRelay = relayIdx;
  document.getElementById('timerModalRelayName').textContent = '\u2014 ' + relayMeta[relayIdx].name;
  openModal('timerModal');
}
document.getElementById('timerModalClose').addEventListener('click', () => closeModal('timerModal'));
document.getElementById('timerStart').addEventListener('click', () => {
  const durVal = +document.getElementById('timerDuration').value || 0;
  const unit = +document.getElementById('timerUnit').value;
  const action = document.getElementById('timerAction').value === 'true';
  if (durVal <= 0) { showToast('Durasi harus lebih dari 0', true); return; }
  publishJSON(T.cmdRelayTimer(), { relay: activeTimerRelay + 1, duration: durVal * unit, state: action });
  closeModal('timerModal');
  showToast('Timer relay dimulai');
});

// --- Schedule modal ---
function openScheduleModal(existing) {
  editingScheduleIndex = existing ? existing.index : null;
  document.getElementById('schRelay').value = existing ? existing.relay : 0;
  const mode = existing ? (existing.mode || 0) : 0;
  document.getElementById('schMode').value = mode;
  toggleScheduleModeFields(mode);

  document.getElementById('schOnTime').value = existing ? `${pad(existing.onHour)}:${pad(existing.onMinute)}` : '06:00';
  document.getElementById('schOffTime').value = existing ? `${pad(existing.offHour)}:${pad(existing.offMinute)}` : '18:00';
  document.getElementById('schOnAnchor').value = existing ? (existing.onAnchor != null ? existing.onAnchor : 1) : 1;
  document.getElementById('schOnOffset').value = existing ? (existing.onOffsetMin || 0) : 0;
  document.getElementById('schOffAnchor').value = existing ? (existing.offAnchor != null ? existing.offAnchor : 0) : 0;
  document.getElementById('schOffOffset').value = existing ? (existing.offOffsetMin || 0) : 0;

  document.getElementById('schEnabled').checked = existing ? existing.enabled : true;
  const days = existing ? existing.days : [true,true,true,true,true,true,true];
  document.querySelectorAll('#schDays button').forEach((b,i) => b.classList.toggle('is-active', !!days[i]));
  openModal('scheduleModal');
}
function toggleScheduleModeFields(mode) {
  document.getElementById('schFixedFields').hidden = (mode != 0);
  document.getElementById('schAstroFields').hidden = (mode == 0);
}
document.getElementById('schMode').addEventListener('change', (e) => toggleScheduleModeFields(+e.target.value));
document.getElementById('btnAddSchedule').addEventListener('click', () => openScheduleModal(null));
document.getElementById('scheduleModalClose').addEventListener('click', () => closeModal('scheduleModal'));
document.querySelectorAll('#schDays button').forEach(b => b.addEventListener('click', () => b.classList.toggle('is-active')));
document.getElementById('schSave').addEventListener('click', () => {
  const mode = +document.getElementById('schMode').value;
  const [onH, onM] = document.getElementById('schOnTime').value.split(':').map(Number);
  const [offH, offM] = document.getElementById('schOffTime').value.split(':').map(Number);
  const days = Array.from(document.querySelectorAll('#schDays button')).map(b => b.classList.contains('is-active'));
  publishJSON(T.cmdScheduleSet(), {
    index: editingScheduleIndex,
    relay: +document.getElementById('schRelay').value + 1,
    mode,
    onHour: onH, onMinute: onM, offHour: offH, offMinute: offM,
    onAnchor: +document.getElementById('schOnAnchor').value,
    onOffsetMin: +document.getElementById('schOnOffset').value || 0,
    offAnchor: +document.getElementById('schOffAnchor').value,
    offOffsetMin: +document.getElementById('schOffOffset').value || 0,
    days, enabled: document.getElementById('schEnabled').checked
  });
  closeModal('scheduleModal');
  showToast('Jadwal disimpan');
});

// --- Rule modal ---
function openRuleModal(existing) {
  editingRuleIndex = existing ? existing.index : null;
  document.getElementById('ruleSensor').value = existing ? existing.sensor : 'T';
  document.getElementById('ruleOperator').value = existing ? existing.operator : '>';
  document.getElementById('ruleValue').value = existing ? existing.value : 30;
  document.getElementById('ruleRelay').value = existing ? existing.relay : 0;
  document.getElementById('ruleState').value = existing ? String(existing.state) : 'true';
  document.getElementById('ruleEnabled').checked = existing ? existing.enabled : true;
  updateRuleHint();
  openModal('ruleModal');
}
document.getElementById('btnAddRule').addEventListener('click', () => openRuleModal(null));
document.getElementById('ruleModalClose').addEventListener('click', () => closeModal('ruleModal'));
['ruleSensor','ruleOperator','ruleValue'].forEach(id => document.getElementById(id).addEventListener('input', updateRuleHint));
function updateRuleHint() {
  document.getElementById('ruleHintSensor').textContent = document.getElementById('ruleSensor').value === 'H' ? 'Kelembaban' : 'Suhu';
  document.getElementById('ruleHintOp').textContent = document.getElementById('ruleOperator').value;
  document.getElementById('ruleHintVal').textContent = document.getElementById('ruleValue').value;
}
document.getElementById('ruleSave').addEventListener('click', () => {
  publishJSON(T.cmdAutomationSet(), {
    index: editingRuleIndex,
    sensor: document.getElementById('ruleSensor').value,
    operator: document.getElementById('ruleOperator').value,
    value: parseFloat(document.getElementById('ruleValue').value),
    relay: +document.getElementById('ruleRelay').value + 1,
    state: document.getElementById('ruleState').value === 'true',
    enabled: document.getElementById('ruleEnabled').checked
  });
  closeModal('ruleModal');
  showToast('Rule disimpan');
});

// -------------------------------------------------------------------------
// 11. PENGATURAN TAB
// -------------------------------------------------------------------------
function fillConfigForm() {
  document.getElementById('cfgHost').value = cfg.host;
  document.getElementById('cfgPort').value = cfg.port;
  document.getElementById('cfgProtocol').value = cfg.protocol;
  document.getElementById('cfgPath').value = cfg.path;
  document.getElementById('cfgUser').value = cfg.username;
  document.getElementById('cfgPass').value = cfg.password;
  document.getElementById('cfgPrefix').value = cfg.prefix;
}
document.getElementById('btnSaveConfig').addEventListener('click', () => {
  cfg = {
    host: document.getElementById('cfgHost').value.trim(),
    port: +document.getElementById('cfgPort').value || 8083,
    protocol: document.getElementById('cfgProtocol').value,
    path: document.getElementById('cfgPath').value.trim() || '/mqtt',
    username: document.getElementById('cfgUser').value,
    password: document.getElementById('cfgPass').value,
    prefix: document.getElementById('cfgPrefix').value.trim()
  };
  saveJSON('mqttConfig', cfg);
  connectMQTT();
  showToast('Konfigurasi disimpan, menghubungkan\u2026');
});
document.getElementById('btnRequestStatus').addEventListener('click', () => {
  publishJSON(T.cmdRequestStatus(), {});
  showToast('Meminta status terbaru dari perangkat');
});
document.getElementById('btnSyncTime').addEventListener('click', () => {
  publishJSON(T.cmdRtcSet(), { epoch: Math.floor(Date.now() / 1000) });
  showToast('Perintah sinkronisasi waktu dikirim');
});
document.getElementById('btnClearChart').addEventListener('click', () => {
  if (!confirm('Hapus semua riwayat grafik?')) return;
  history = [];
  saveJSON('sensorHistory', history);
  updateChart();
  showToast('Riwayat grafik dihapus');
});

// -------------------------------------------------------------------------
// 11b. LOKASI (untuk jadwal matahari)
// -------------------------------------------------------------------------
function fillLocationForm() {
  if (state.location.lat != null) document.getElementById('locLat').value = state.location.lat;
  if (state.location.lon != null) document.getElementById('locLon').value = state.location.lon;
}
document.getElementById('btnSaveLocation').addEventListener('click', () => {
  const lat = parseFloat(document.getElementById('locLat').value);
  const lon = parseFloat(document.getElementById('locLon').value);
  if (isNaN(lat) || isNaN(lon)) { showToast('Latitude/Longitude tidak valid', true); return; }
  publishJSON(T.cmdLocationSet(), { lat, lon });
  showToast('Lokasi disimpan, menghitung ulang jam matahari\u2026');
});

// -------------------------------------------------------------------------
// 11c. NOTIFIKASI & ALERT
// -------------------------------------------------------------------------
function initNotifToggle() {
  const enabled = localStorage.getItem('notifBrowserEnabled') === 'true' &&
    typeof Notification !== 'undefined' && Notification.permission === 'granted';
  document.getElementById('notifBrowserToggle').checked = enabled;
  updateNotifHint();
}
function updateNotifHint() {
  const hint = document.getElementById('notifPermHint');
  if (typeof Notification === 'undefined') {
    hint.innerHTML = '<i class="las la-exclamation-circle"></i> Browser ini tidak mendukung notifikasi.';
  } else if (Notification.permission === 'denied') {
    hint.innerHTML = '<i class="las la-exclamation-circle"></i> Izin notifikasi diblokir. Aktifkan lewat pengaturan browser.';
  } else {
    hint.innerHTML = '<i class="las la-info-circle"></i> Notifikasi hanya muncul selagi browser berjalan.';
  }
}
document.getElementById('notifBrowserToggle').addEventListener('change', async (e) => {
  if (!e.target.checked) {
    localStorage.setItem('notifBrowserEnabled', 'false');
    return;
  }
  if (typeof Notification === 'undefined') {
    e.target.checked = false;
    showToast('Browser ini tidak mendukung notifikasi', true);
    return;
  }
  const perm = await Notification.requestPermission();
  if (perm === 'granted') {
    localStorage.setItem('notifBrowserEnabled', 'true');
    showToast('Notifikasi browser diaktifkan');
  } else {
    e.target.checked = false;
    localStorage.setItem('notifBrowserEnabled', 'false');
    showToast('Izin notifikasi ditolak', true);
  }
  updateNotifHint();
});

function fillAlertForm() {
  const a = state.alertSettings;
  document.getElementById('waEnabledToggle').checked = !!a.waEnabled;
  document.getElementById('alertTempHighEn').checked = !!a.tempHighEn;
  document.getElementById('alertTempHighVal').value = a.tempHighVal;
  document.getElementById('alertTempLowEn').checked = !!a.tempLowEn;
  document.getElementById('alertTempLowVal').value = a.tempLowVal;
  document.getElementById('alertHumHighEn').checked = !!a.humHighEn;
  document.getElementById('alertHumHighVal').value = a.humHighVal;
  document.getElementById('alertHumLowEn').checked = !!a.humLowEn;
  document.getElementById('alertHumLowVal').value = a.humLowVal;
  document.getElementById('alertRelayStuckEn').checked = !!a.relayStuckEn;
  document.getElementById('alertRelayStuckVal').value = a.relayStuckMinutes;

  const waHint = document.getElementById('waConfigHint');
  if (a.waEnabled && a.waConfigured === false) {
    waHint.innerHTML = '<i class="las la-exclamation-circle"></i> Firmware belum mengaktifkan <code>WA_ENABLED</code> di config.h — WhatsApp tidak akan terkirim.';
  } else {
    waHint.innerHTML = '<i class="las la-info-circle"></i> Nomor &amp; API key WhatsApp diatur di firmware (<code>config.h</code>) demi keamanan.';
  }
}
document.getElementById('btnSaveAlerts').addEventListener('click', () => {
  publishJSON(T.cmdAlertSet(), {
    waEnabled: document.getElementById('waEnabledToggle').checked,
    tempHighEn: document.getElementById('alertTempHighEn').checked,
    tempHighVal: parseFloat(document.getElementById('alertTempHighVal').value),
    tempLowEn: document.getElementById('alertTempLowEn').checked,
    tempLowVal: parseFloat(document.getElementById('alertTempLowVal').value),
    humHighEn: document.getElementById('alertHumHighEn').checked,
    humHighVal: parseFloat(document.getElementById('alertHumHighVal').value),
    humLowEn: document.getElementById('alertHumLowEn').checked,
    humLowVal: parseFloat(document.getElementById('alertHumLowVal').value),
    relayStuckEn: document.getElementById('alertRelayStuckEn').checked,
    relayStuckMinutes: parseInt(document.getElementById('alertRelayStuckVal').value, 10)
  });
  showToast('Pengaturan alert disimpan');
});

// -------------------------------------------------------------------------
// 11d. LATAR BELAKANG (background image)
// -------------------------------------------------------------------------
function initBackgroundForm() {
  document.querySelectorAll('#bgTypePicker .segmented__btn').forEach(b => {
    b.classList.toggle('is-active', b.dataset.bgtype === bgSettings.type);
  });
  document.getElementById('bgUrlWrap').hidden = bgSettings.type !== 'url';
  document.getElementById('bgUploadWrap').hidden = bgSettings.type !== 'upload';
  document.getElementById('bgUrlInput').value = bgSettings.url || '';
  document.getElementById('bgOverlayRange').value = bgSettings.overlay;
  document.getElementById('bgOverlayVal').textContent = bgSettings.overlay;
  document.getElementById('bgBlurToggle').checked = !!bgSettings.blur;

  try {
    bgImageData = localStorage.getItem('bgImageData') || null;
  } catch (e) { bgImageData = null; }

  applyBackgroundSettings();
}
document.querySelectorAll('#bgTypePicker .segmented__btn').forEach(b => {
  b.addEventListener('click', () => {
    document.querySelectorAll('#bgTypePicker .segmented__btn').forEach(x => x.classList.remove('is-active'));
    b.classList.add('is-active');
    bgSettings.type = b.dataset.bgtype;
    document.getElementById('bgUrlWrap').hidden = bgSettings.type !== 'url';
    document.getElementById('bgUploadWrap').hidden = bgSettings.type !== 'upload';
  });
});
document.getElementById('bgOverlayRange').addEventListener('input', (e) => {
  document.getElementById('bgOverlayVal').textContent = e.target.value;
});
document.getElementById('bgUploadInput').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      // kompres/resize gambar via canvas supaya hemat localStorage
      const maxW = 1280;
      const scale = Math.min(1, maxW / img.width);
      const canvas = document.createElement('canvas');
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      bgImageData = canvas.toDataURL('image/jpeg', 0.72);
      showToast('Gambar siap, klik Terapkan untuk menyimpan');
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});
document.getElementById('btnApplyBg').addEventListener('click', () => {
  bgSettings.url = document.getElementById('bgUrlInput').value.trim();
  bgSettings.overlay = +document.getElementById('bgOverlayRange').value;
  bgSettings.blur = document.getElementById('bgBlurToggle').checked;
  saveJSON('bgSettings', bgSettings);
  if (bgSettings.type === 'upload' && bgImageData) {
    try {
      localStorage.setItem('bgImageData', bgImageData);
    } catch (e) {
      showToast('Gambar terlalu besar untuk disimpan di browser, gunakan URL sebagai gantinya', true);
      return;
    }
  }
  applyBackgroundSettings();
  showToast('Latar belakang diterapkan');
});
document.getElementById('btnRemoveBg').addEventListener('click', () => {
  bgSettings = { ...DEFAULT_BG_SETTINGS };
  bgImageData = null;
  try { localStorage.removeItem('bgImageData'); } catch (e) {}
  saveJSON('bgSettings', bgSettings);
  initBackgroundForm();
  showToast('Latar belakang dihapus');
});
function applyBackgroundSettings() {
  const imageLayer = document.getElementById('bgLayerImage');
  const overlayLayer = document.getElementById('bgLayerOverlay');
  let src = null;
  if (bgSettings.type === 'url' && bgSettings.url) src = bgSettings.url;
  else if (bgSettings.type === 'upload' && bgImageData) src = bgImageData;

  if (src) {
    imageLayer.style.backgroundImage = `url("${src}")`;
    imageLayer.style.filter = bgSettings.blur ? 'blur(14px)' : 'none';
    overlayLayer.style.backgroundColor = themeBgColor();
    overlayLayer.style.opacity = (bgSettings.overlay || 55) / 100;
  } else {
    imageLayer.style.backgroundImage = 'none';
    overlayLayer.style.backgroundColor = themeBgColor();
    overlayLayer.style.opacity = 1;
  }
}
function themeBgColor() {
  return document.body.dataset.theme === 'dark' ? '#262A34' : '#E4E9F0';
}

function renderRelayNameForm() {
  const wrap = document.getElementById('relayNameForm');
  wrap.innerHTML = relayMeta.map((m, i) => `
    <label>Nama Relay ${i + 1}
      <input type="text" data-relay-name="${i}" value="${escapeHtml(m.name)}">
    </label>
    <label>Ikon Relay ${i + 1}
      <select data-relay-icon="${i}">
        ${ICON_OPTIONS.map(o => `<option value="${o.icon}" ${o.icon === m.icon ? 'selected' : ''}>${o.label}</option>`).join('')}
      </select>
    </label>
  `).join('');
}
document.getElementById('btnSaveRelayNames').addEventListener('click', () => {
  document.querySelectorAll('[data-relay-name]').forEach(inp => {
    relayMeta[+inp.dataset.relayName].name = inp.value.trim() || ('Relay ' + (+inp.dataset.relayName + 1));
  });
  document.querySelectorAll('[data-relay-icon]').forEach(sel => {
    relayMeta[+sel.dataset.relayIcon].icon = sel.value;
  });
  saveJSON('relayMeta', relayMeta);
  renderRelayGrid();
  renderRelaySelects();
  showToast('Nama & ikon relay disimpan');
});

// -------------------------------------------------------------------------
// 12. CHART RANGE SEGMENTED CONTROL
// -------------------------------------------------------------------------
document.querySelectorAll('#chartRange .segmented__btn').forEach(b => {
  b.addEventListener('click', () => {
    document.querySelectorAll('#chartRange .segmented__btn').forEach(x => x.classList.remove('is-active'));
    b.classList.add('is-active');
    chartRangeCount = +b.dataset.range;
    updateChart();
  });
});

// -------------------------------------------------------------------------
// 13. UTIL
// -------------------------------------------------------------------------
function publishJSON(topic, obj) {
  if (!mqttClient || !mqttClient.connected) { showToast('Belum terhubung ke broker MQTT', true); return; }
  mqttClient.publish(topic, JSON.stringify(obj));
}
function pad(n) { return String(n).padStart(2, '0'); }
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
let toastTimeout;
function showToast(msg, isError) {
  const el = document.getElementById('toast');
  el.innerHTML = `<i class="las ${isError ? 'la-exclamation-circle' : 'la-check-circle'}"></i> ${escapeHtml(msg)}`;
  el.className = 'toast is-visible ' + (isError ? 'is-error' : 'is-success');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => el.classList.remove('is-visible'), 3000);
}

// -------------------------------------------------------------------------
// 14. INIT
// -------------------------------------------------------------------------
// Menjalankan sebuah fungsi init dengan aman — kalau satu langkah gagal
// (mis. CDN Chart.js lambat/gagal dimuat), langkah-langkah berikutnya
// (terutama connectMQTT) tetap berjalan alih-alih ikut batal semua.
function safeInit(fn) {
  try { fn(); } catch (e) { console.error('[init gagal]', fn.name || fn, e); }
}

document.addEventListener('DOMContentLoaded', () => {
  safeInit(initTheme);
  safeInit(initTabs);
  safeInit(initStickySummaryObserver);
  safeInit(fillConfigForm);
  safeInit(renderRelaySelects);
  safeInit(renderRelayNameForm);
  safeInit(renderRelayGrid);
  safeInit(renderScheduleList);
  safeInit(renderRuleList);
  safeInit(renderAlertLog);
  safeInit(renderSensor);
  safeInit(renderSunInfo);
  safeInit(fillLocationForm);
  safeInit(fillAlertForm);
  safeInit(initNotifToggle);
  safeInit(initBackgroundForm);
  safeInit(initChart);
  // Koneksi MQTT adalah yang paling krusial — dijalankan terakhir dan
  // tidak boleh pernah gagal dipanggil hanya karena langkah lain error.
  safeInit(connectMQTT);
});
